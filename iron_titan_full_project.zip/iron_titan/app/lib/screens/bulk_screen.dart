import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import '../widgets/common.dart';
import '../widgets/content_views.dart';
import '../widgets/exercise_view.dart';

/// "Muscle gain" section: full bulking guide + macro calculator + exercises.
class BulkScreen extends StatefulWidget {
  const BulkScreen({super.key});

  @override
  State<BulkScreen> createState() => _BulkScreenState();
}

class _BulkScreenState extends State<BulkScreen> {
  final TextEditingController _weightCtrl = TextEditingController(text: '75');
  double _weight = 75;

  @override
  void dispose() {
    _weightCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final guide = repo.bulkGuide;

    final protein = _weight * 2.0;
    final carbs = _weight * 4.0;
    final fat = _weight * 0.9;
    final water = _weight * 0.035 + 0.5;
    final calories = protein * 4 + carbs * 4 + fat * 9;

    return AppPage(
      title: context.t('bulk_title'),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: SizedBox(
              height: 170,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    'assets/images/legs.jpg',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const ColoredBox(color: Color(0xFF14141A)),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerRight,
                        end: Alignment.centerLeft,
                        colors: [Color(0xCC000000), Color(0x22000000)],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 16,
                    bottom: 14,
                    right: 16,
                    child: Text(
                      context.t('bulk_sub'),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          SectionHeader(title: context.t('bulk_calc_title')),
          GoldCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _weightCtrl,
                        keyboardType:
                            const TextInputType.numberWithOptions(decimal: true),
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
                        ],
                        decoration: InputDecoration(
                          labelText: context.t('label_weight'),
                          suffixText: context.t('label_kg'),
                          isDense: true,
                        ),
                        onChanged: (value) {
                          final parsed =
                              double.tryParse(value.replaceAll(',', '.'));
                          if (parsed != null && parsed > 25 && parsed < 300) {
                            setState(() => _weight = parsed);
                          }
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                StatRow(
                  icon: Icons.local_fire_department,
                  label: context.t('label_calories'),
                  value: '${calories.round()}',
                ),
                StatRow(
                  icon: Icons.egg_alt_outlined,
                  label: context.t('label_protein'),
                  value: '${protein.round()} g',
                ),
                StatRow(
                  icon: Icons.rice_bowl_outlined,
                  label: context.t('label_carbs'),
                  value: '${carbs.round()} g',
                ),
                StatRow(
                  icon: Icons.opacity,
                  label: context.t('label_fat'),
                  value: '${fat.round()} g',
                ),
                StatRow(
                  icon: Icons.water_drop_outlined,
                  label: context.t('label_water'),
                  value: '${water.toStringAsFixed(1)} L',
                ),
                const SizedBox(height: 6),
                Text(
                  context.t('bulk_calc_hint'),
                  style: TextStyle(
                    fontSize: 11.5,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          if (guide != null) ...[
            ParagraphCard(
              title: context.tr(guide.title),
              body: context.tr(guide.intro),
              icon: Icons.menu_book,
            ),
            const SizedBox(height: 14),
            NumberedSteps(steps: guide.steps),
            const SizedBox(height: 8),
          ],
          if (repo.trainingTime != null) ...[
            ParagraphCard(
              title: context.tr(repo.trainingTime!.title),
              body: context.tr(repo.trainingTime!.body),
              icon: Icons.schedule,
            ),
            const SizedBox(height: 20),
          ],
          MuscleGroupsList(
            groupIds: const ['chest', 'back', 'shoulders', 'arms', 'legs', 'abs'],
          ),
          const SizedBox(height: 12),
          if (repo.mistakes.isNotEmpty)
            BulletCard(
              title: context.tr(repo.mistakesTitle),
              items: repo.mistakes,
              icon: Icons.warning_amber_outlined,
            ),
        ],
      ),
    );
  }
}
