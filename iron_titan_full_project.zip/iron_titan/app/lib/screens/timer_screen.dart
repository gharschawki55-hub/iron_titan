import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/theme.dart';
import '../widgets/common.dart';

/// `num.clamp` is typed `num`, so integer bounds need an explicit conversion.
int _clampInt(int value, int lower, int upper) =>
    value.clamp(lower, upper).toInt();

/// Interval timer: work / rest / rounds with haptic feedback.
class TimerScreen extends StatefulWidget {
  const TimerScreen({super.key});

  @override
  State<TimerScreen> createState() => _TimerScreenState();
}

class _TimerScreenState extends State<TimerScreen> {
  int _workSeconds = 45;
  int _restSeconds = 60;
  int _rounds = 4;

  int _remaining = 45;
  int _round = 1;
  String _phase = 'idle'; // idle | work | rest | done
  bool _running = false;
  Timer? _ticker;

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  int get _phaseTotal {
    if (_phase == 'rest') return _restSeconds;
    if (_phase == 'work') return _workSeconds;
    return _workSeconds;
  }

  void _start() {
    if (_running) return;
    if (_phase == 'done') {
      _reset();
    }
    setState(() {
      _running = true;
      if (_phase == 'idle') {
        _phase = 'work';
        _remaining = _workSeconds;
      }
    });
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _pause() {
    _ticker?.cancel();
    setState(() => _running = false);
  }

  void _reset() {
    _ticker?.cancel();
    setState(() {
      _running = false;
      _phase = 'idle';
      _round = 1;
      _remaining = _workSeconds;
    });
  }

  void _skip() {
    _ticker?.cancel();
    setState(() => _running = false);
    _advance(force: true);
  }

  void _tick() {
    if (_remaining > 1) {
      setState(() => _remaining--);
      return;
    }
    _advance();
  }

  void _advance({bool force = false}) {
    HapticFeedback.mediumImpact();
    SystemSound.play(SystemSoundType.alert);

    if (_phase == 'work' || force && _phase == 'work') {
      if (_round >= _rounds) {
        _ticker?.cancel();
        setState(() {
          _phase = 'done';
          _running = false;
          _remaining = 0;
        });
        return;
      }
      setState(() {
        _phase = 'rest';
        _remaining = _restSeconds;
        _running = !force && _running;
      });
      return;
    }

    if (_phase == 'rest') {
      setState(() {
        _round++;
        _phase = 'work';
        _remaining = _workSeconds;
        _running = !force && _running;
      });
      return;
    }

    if (_phase == 'idle') {
      setState(() {
        _phase = 'work';
        _remaining = _workSeconds;
      });
    }
  }

  Color _phaseColor(BuildContext context) {
    switch (_phase) {
      case 'rest':
        return const Color(0xFF2F6BFF);
      case 'done':
        return const Color(0xFF17B26A);
      default:
        return context.accent;
    }
  }

  String _phaseLabel(BuildContext context) {
    switch (_phase) {
      case 'work':
        return context.t('timer_work');
      case 'rest':
        return context.t('timer_rest_time');
      case 'done':
        return context.t('timer_done');
      default:
        return context.t('timer_title');
    }
  }

  String get _clockText {
    final total = _remaining;
    final minutes = (total ~/ 60).toString().padLeft(2, '0');
    final seconds = (total % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final color = _phaseColor(context);
    final double progress = _phase == 'idle'
        ? 0.0
        : (_phaseTotal == 0
                ? 0.0
                : 1 - (_remaining / _phaseTotal))
            .clamp(0.0, 1.0)
            .toDouble();

    return AppPage(
      title: context.t('timer_title'),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 28),
        children: [
          Center(
            child: SizedBox(
              width: 250,
              height: 250,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 250,
                    height: 250,
                    child: CircularProgressIndicator(
                      value: progress,
                      strokeWidth: 12,
                      backgroundColor: color.withOpacity(0.14),
                      valueColor: AlwaysStoppedAnimation<Color>(color),
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        _phaseLabel(context),
                        style: TextStyle(
                          fontSize: 12.5,
                          letterSpacing: 2,
                          fontWeight: FontWeight.w700,
                          color: color,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        _clockText,
                        style: const TextStyle(
                          fontSize: 54,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${context.t('timer_round')} $_round / $_rounds',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withOpacity(0.65),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 26),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _running ? _pause : _start,
                  icon: Icon(
                    _running ? Icons.pause_rounded : Icons.play_arrow_rounded,
                  ),
                  label: Text(
                    _running ? context.t('action_pause') : context.t('action_start'),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: 58,
                width: 58,
                child: OutlinedButton(
                  onPressed: _reset,
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.zero,
                    minimumSize: const Size(58, 58),
                  ),
                  child: const Icon(Icons.refresh, size: 22),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: 58,
                width: 58,
                child: OutlinedButton(
                  onPressed: _skip,
                  style: OutlinedButton.styleFrom(
                    padding: EdgeInsets.zero,
                    minimumSize: const Size(58, 58),
                  ),
                  child: const Icon(Icons.skip_next, size: 22),
                ),
              ),
            ],
          ),
          const SizedBox(height: 26),
          GoldCard(
            child: Column(
              children: [
                _Stepper(
                  label: context.t('timer_work'),
                  value: '$_workSeconds ${context.t('label_seconds')}',
                  onMinus: () => _change(() {
                    _workSeconds = _clampInt(_workSeconds - 5, 5, 600);
                    if (!_running) _remaining = _workSeconds;
                  }),
                  onPlus: () => _change(() {
                    _workSeconds = _clampInt(_workSeconds + 5, 5, 600);
                    if (!_running) _remaining = _workSeconds;
                  }),
                ),
                Divider(color: context.accent.withOpacity(0.15)),
                _Stepper(
                  label: context.t('timer_rest_time'),
                  value: '$_restSeconds ${context.t('label_seconds')}',
                  onMinus: () => _change(() {
                    _restSeconds = _clampInt(_restSeconds - 5, 5, 600);
                  }),
                  onPlus: () => _change(() {
                    _restSeconds = _clampInt(_restSeconds + 5, 5, 600);
                  }),
                ),
                Divider(color: context.accent.withOpacity(0.15)),
                _Stepper(
                  label: context.t('timer_rounds'),
                  value: '$_rounds',
                  onMinus: () => _change(() {
                    _rounds = _clampInt(_rounds - 1, 1, 30);
                  }),
                  onPlus: () => _change(() {
                    _rounds = _clampInt(_rounds + 1, 1, 30);
                  }),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Text(
            context.t('timer_hint'),
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  void _change(VoidCallback action) {
    setState(action);
  }
}

class _Stepper extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onMinus;
  final VoidCallback onPlus;

  const _Stepper({
    required this.label,
    required this.value,
    required this.onMinus,
    required this.onPlus,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14.5))),
          IconButton(
            onPressed: onMinus,
            icon: const Icon(Icons.remove_circle_outline),
            color: context.accent,
          ),
          SizedBox(
            width: 74,
            child: Text(
              value,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w800,
                color: context.accent,
              ),
            ),
          ),
          IconButton(
            onPressed: onPlus,
            icon: const Icon(Icons.add_circle_outline),
            color: context.accent,
          ),
        ],
      ),
    );
  }
}
