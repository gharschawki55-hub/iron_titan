import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import '../services/body_analysis_service.dart';
import '../widgets/common.dart';
import 'programs_screen.dart';

/// "Analyse my body": gallery photo + measurements -> personal program.
/// Everything is computed on the device, so the feature works without internet.
class AnalysisScreen extends StatefulWidget {
  final bool embedded;

  const AnalysisScreen({super.key, this.embedded = false});

  @override
  State<AnalysisScreen> createState() => _AnalysisScreenState();
}

class _AnalysisScreenState extends State<AnalysisScreen> {
  String? _photoPath;
  bool _male = true;
  String _goal = 'auto';
  String _priority = '';
  int _months = 6;
  bool _busy = false;
  BodyAnalysisResult? _result;

  final _age = TextEditingController(text: '28');
  final _height = TextEditingController(text: '175');
  final _weight = TextEditingController(text: '78');
  final _waist = TextEditingController(text: '85');
  final _neck = TextEditingController(text: '40');
  final _chest = TextEditingController(text: '100');
  final _arm = TextEditingController(text: '35');
  final _hip = TextEditingController(text: '95');

  @override
  void dispose() {
    for (final c in [_age, _height, _weight, _waist, _neck, _chest, _arm, _hip]) {
      c.dispose();
    }
    super.dispose();
  }

  double _parse(TextEditingController c, double fallback) {
    final value = double.tryParse(c.text.replaceAll(',', '.'));
    if (value == null || value <= 0) return fallback;
    return value;
  }

  Future<void> _pickPhoto() async {
    try {
      final picker = ImagePicker();
      final picked = await picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1600,
        imageQuality: 88,
      );
      if (picked == null) return;
      setState(() => _photoPath = picked.path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.t('common_error'))),
      );
    }
  }

  Future<void> _analyse() async {
    setState(() => _busy = true);
    await Future<void>.delayed(const Duration(milliseconds: 260));
    final profile = BodyProfile(
      male: _male,
      age: _parse(_age, 28).round(),
      heightCm: _parse(_height, 175),
      weightKg: _parse(_weight, 78),
      waistCm: _parse(_waist, 0),
      neckCm: _parse(_neck, 0),
      chestCm: _parse(_chest, 0),
      armCm: _parse(_arm, 0),
      hipCm: _parse(_hip, 0),
      trainingMonths: _months,
      goal: _goal,
      priority: _priority,
      photoPath: _photoPath,
    );
    final result = BodyAnalysisService.analyse(profile);
    if (!mounted) return;
    setState(() {
      _result = result;
      _busy = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final content = ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        _PhotoCard(
          path: _photoPath,
          onPick: _pickPhoto,
        ),
        const SizedBox(height: 16),
        GoldCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                context.t('label_gender'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  _choice(context, context.t('label_male'), _male,
                      () => setState(() => _male = true)),
                  _choice(context, context.t('label_female'), !_male,
                      () => setState(() => _male = false)),
                ],
              ),
              const SizedBox(height: 16),
              _pair(
                context,
                _Field(controller: _age, label: context.t('label_age')),
                _Field(controller: _height, label: context.t('label_height'), suffix: context.t('label_cm')),
              ),
              _pair(
                context,
                _Field(controller: _weight, label: context.t('label_weight'), suffix: context.t('label_kg')),
                _Field(controller: _waist, label: context.t('label_waist'), suffix: context.t('label_cm')),
              ),
              _pair(
                context,
                _Field(controller: _neck, label: context.t('label_neck'), suffix: context.t('label_cm')),
                _Field(controller: _chest, label: context.t('label_chest'), suffix: context.t('label_cm')),
              ),
              _pair(
                context,
                _Field(controller: _arm, label: context.t('label_arm'), suffix: context.t('label_cm')),
                _male
                    ? const SizedBox.shrink()
                    : _Field(controller: _hip, label: context.t('label_hip'), suffix: context.t('label_cm')),
              ),
              const SizedBox(height: 14),
              Text(
                context.t('label_experience'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _choice(context, context.t('label_beginner'), _months == 2,
                      () => setState(() => _months = 2)),
                  _choice(context, context.t('label_intermediate'), _months == 18,
                      () => setState(() => _months = 18)),
                  _choice(context, context.t('label_advanced'), _months == 48,
                      () => setState(() => _months = 48)),
                ],
              ),
              const SizedBox(height: 14),
              Text(
                context.t('label_goal'),
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  _choice(context, context.t('settings_system'), _goal == 'auto',
                      () => setState(() => _goal = 'auto')),
                  _choice(context, context.t('bulk_title'), _goal == 'bulk',
                      () => setState(() => _goal = 'bulk')),
                  _choice(context, context.t('cut_title'), _goal == 'cut',
                      () => setState(() => _goal = 'cut')),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                height: 56,
                child: ElevatedButton.icon(
                  onPressed: _busy ? null : _analyse,
                  icon: _busy
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.analytics_outlined),
                  label: Text(
                    _result == null
                        ? context.t('analysis_run')
                        : context.t('analysis_recompute'),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                context.t('analysis_note'),
                style: TextStyle(
                  fontSize: 11.5,
                  height: 1.4,
                  color: Theme.of(context)
                      .colorScheme
                      .onSurface
                      .withOpacity(0.6),
                ),
              ),
            ],
          ),
        ),
        if (_result != null) ...[
          const SizedBox(height: 20),
          _ResultView(result: _result!),
        ],
      ],
    );

    if (widget.embedded) return content;
    return AppPage(title: context.t('analysis_title'), child: content);
  }

  Widget _pair(BuildContext context, Widget a, Widget b) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(child: a),
          const SizedBox(width: 10),
          Expanded(child: b),
        ],
      ),
    );
  }

  Widget _choice(
    BuildContext context,
    String label,
    bool selected,
    VoidCallback onTap,
  ) {
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => onTap(),
      selectedColor: context.accent.withOpacity(0.25),
      showCheckmark: false,
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String? suffix;

  const _Field({required this.controller, required this.label, this.suffix});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]'))],
      decoration: InputDecoration(
        labelText: label,
        suffixText: suffix,
        isDense: true,
      ),
    );
  }
}

class _PhotoCard extends StatelessWidget {
  final String? path;
  final VoidCallback onPick;

  const _PhotoCard({required this.path, required this.onPick});

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    if (path == null) {
      return GoldCard(
        child: Column(
          children: [
            Container(
              height: 150,
              decoration: BoxDecoration(
                color: accent.withOpacity(0.06),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: accent.withOpacity(0.4),
                  style: BorderStyle.solid,
                ),
              ),
              child: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.add_a_photo_outlined, size: 34, color: accent),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        context.t('analysis_photo_hint'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12.5, height: 1.4),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 50,
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: onPick,
                icon: const Icon(Icons.photo_library_outlined, size: 20),
                label: Text(context.t('analysis_pick')),
              ),
            ),
          ],
        ),
      );
    }

    return GoldCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: SizedBox(
              height: 260,
              width: double.infinity,
              child: Image.file(
                File(path!),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: accent.withOpacity(0.1),
                  child: Icon(Icons.broken_image_outlined, color: accent),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Icon(Icons.check_circle, size: 18, color: accent),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    context.t('analysis_photo_ok'),
                    style: const TextStyle(fontSize: 12.5),
                  ),
                ),
                TextButton(
                  onPressed: onPick,
                  child: Text(context.t('analysis_pick')),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ResultView extends StatelessWidget {
  final BodyAnalysisResult result;

  const _ResultView({required this.result});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final accent = context.accent;

    final directionLabel = result.direction == 'bulk'
        ? context.t('analysis_bulk_needed')
        : result.direction == 'cut'
            ? context.t('analysis_cut_needed')
            : context.t('analysis_maintain');

    final directionIcon = result.direction == 'bulk'
        ? Icons.trending_up
        : result.direction == 'cut'
            ? Icons.trending_down
            : Icons.balance;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GoldCard(
          background: accent.withOpacity(context.isDark ? 0.12 : 0.10),
          child: Row(
            children: [
              Icon(directionIcon, color: accent, size: 26),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      context.t('analysis_direction'),
                      style: TextStyle(
                        fontSize: 11,
                        letterSpacing: 1.6,
                        fontWeight: FontWeight.w700,
                        color: accent,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      directionLabel,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        GoldCard(
          child: Column(
            children: [
              StatRow(
                icon: Icons.monitor_weight_outlined,
                label: context.t('label_bmi'),
                value: result.bmi.toStringAsFixed(1),
              ),
              StatRow(
                icon: Icons.percent,
                label: context.t('label_body_fat'),
                value: '${result.bodyFatPct.toStringAsFixed(1)} %',
              ),
              StatRow(
                icon: Icons.local_fire_department,
                label: context.t('label_calories'),
                value: '${result.calories.round()}',
              ),
              StatRow(
                icon: Icons.egg_alt_outlined,
                label: context.t('label_protein'),
                value: '${result.proteinG.round()} g',
              ),
              StatRow(
                icon: Icons.rice_bowl_outlined,
                label: context.t('label_carbs'),
                value: '${result.carbsG.round()} g',
              ),
              StatRow(
                icon: Icons.opacity,
                label: context.t('label_fat'),
                value: '${result.fatG.round()} g',
              ),
              StatRow(
                icon: Icons.water_drop_outlined,
                label: context.t('label_water'),
                value: '${result.waterL.toStringAsFixed(1)} L',
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (result.weakGroups.isNotEmpty)
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.t('analysis_weak'),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final id in result.weakGroups)
                      Chip(
                        label: Text(
                          repo.groupsById[id] != null
                              ? context.tr(repo.groupsById[id]!.name)
                              : id,
                        ),
                        avatar: Icon(Icons.priority_high,
                            size: 14, color: accent),
                      ),
                  ],
                ),
              ],
            ),
          ),
        if (result.strongGroups.isNotEmpty) ...[
          const SizedBox(height: 12),
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.t('analysis_strong'),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final id in result.strongGroups)
                      Chip(
                        label: Text(
                          repo.groupsById[id] != null
                              ? context.tr(repo.groupsById[id]!.name)
                              : id,
                        ),
                        avatar: Icon(Icons.star_border,
                            size: 14, color: accent),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        GoldCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                context.t('analysis_exercises'),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 8),
              for (final ref in result.focusRefs)
                Bullet(
                  repo.exerciseFor(ref) != null
                      ? context.tr(repo.exerciseFor(ref)!.name)
                      : ref,
                  icon: Icons.fitness_center,
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        GoldCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                context.t('analysis_your_program'),
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                result.programId == 'cutting'
                    ? context.t('prog_cut')
                    : context.t('prog_bulk'),
                style: TextStyle(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w700,
                  color: accent,
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 48,
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () => pushPage(context, const ProgramsScreen()),
                  icon: const Icon(Icons.calendar_view_week, size: 18),
                  label: Text(context.t('prog_title')),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
