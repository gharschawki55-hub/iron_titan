import 'dart:convert';

import 'package:flutter/services.dart';

/// ---------------------------------------------------------------------------
/// Content model + offline repository.
/// Every string is bundled in assets/data/content/*.json, so the app never
/// needs the network to display a single word.
/// ---------------------------------------------------------------------------

class Exercise {
  final Map<String, dynamic> name;
  final Map<String, dynamic> cue;
  final int sets;
  final String reps;
  final String rest;
  final String tempo;

  Exercise({
    required this.name,
    required this.cue,
    required this.sets,
    required this.reps,
    required this.rest,
    required this.tempo,
  });

  static Exercise fromJson(Map<String, dynamic> j) => Exercise(
        name: _map(j['name']),
        cue: _map(j['cue']),
        sets: _int(j['sets'], 3),
        reps: '${j['reps'] ?? '10'}',
        rest: '${j['rest'] ?? '60'}',
        tempo: '${j['tempo'] ?? ''}',
      );
}

class MuscleGroup {
  final String id;
  final String image;
  final Map<String, dynamic> name;
  final Map<String, dynamic> focus;
  final List<Exercise> items;

  MuscleGroup({
    required this.id,
    required this.image,
    required this.name,
    required this.focus,
    required this.items,
  });

  static MuscleGroup fromJson(Map<String, dynamic> j) => MuscleGroup(
        id: '${j['id']}',
        image: '${j['image'] ?? ''}',
        name: _map(j['name']),
        focus: _map(j['focus']),
        items: _list(j['items']).map(Exercise.fromJson).toList(),
      );
}

class ProgramItem {
  final String ref;
  final int sets;
  final String reps;
  final String rest;

  ProgramItem({
    required this.ref,
    required this.sets,
    required this.reps,
    required this.rest,
  });

  static ProgramItem fromJson(Map<String, dynamic> j) => ProgramItem(
        ref: '${j['ref']}',
        sets: _int(j['sets'], 3),
        reps: '${j['reps'] ?? '10'}',
        rest: '${j['rest'] ?? '60'}',
      );
}

class ProgramDay {
  final String id;
  final Map<String, dynamic> label;
  final String image;
  final List<ProgramItem> items;

  ProgramDay({
    required this.id,
    required this.label,
    required this.image,
    required this.items,
  });

  static ProgramDay fromJson(Map<String, dynamic> j) => ProgramDay(
        id: '${j['id']}',
        label: _map(j['label']),
        image: '${j['image'] ?? ''}',
        items: _list(j['items']).map(ProgramItem.fromJson).toList(),
      );
}

class Program {
  final String id;
  final Map<String, dynamic> title;
  final Map<String, dynamic> subtitle;
  final String image;
  final List<ProgramDay> days;

  Program({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.image,
    required this.days,
  });

  static Program fromJson(Map<String, dynamic> j) => Program(
        id: '${j['id']}',
        title: _map(j['title']),
        subtitle: _map(j['subtitle']),
        image: '${j['image'] ?? ''}',
        days: _list(j['days']).map(ProgramDay.fromJson).toList(),
      );
}

class MealItem {
  final Map<String, dynamic> name;
  final Map<String, dynamic> amount;
  final int kcal;

  MealItem({required this.name, required this.amount, required this.kcal});

  static MealItem fromJson(Map<String, dynamic> j) => MealItem(
        name: _map(j['name']),
        amount: _map(j['amount']),
        kcal: _int(j['kcal'], 0),
      );
}

class Meal {
  final String id;
  final String image;
  final Map<String, dynamic> title;
  final Map<String, dynamic> time;
  final Map<String, dynamic> note;
  final List<MealItem> items;

  Meal({
    required this.id,
    required this.image,
    required this.title,
    required this.time,
    required this.note,
    required this.items,
  });

  static Meal fromJson(Map<String, dynamic> j) => Meal(
        id: '${j['id']}',
        image: '${j['image'] ?? ''}',
        title: _map(j['title']),
        time: _map(j['time']),
        note: _map(j['note']),
        items: _list(j['items']).map(MealItem.fromJson).toList(),
      );
}

class Supplement {
  final Map<String, dynamic> name;
  final Map<String, dynamic> dose;
  final Map<String, dynamic> note;

  Supplement({required this.name, required this.dose, required this.note});

  static Supplement fromJson(Map<String, dynamic> j) => Supplement(
        name: _map(j['name']),
        dose: _map(j['dose']),
        note: _map(j['note']),
      );
}

class TextBlock {
  final Map<String, dynamic> title;
  final Map<String, dynamic> body;

  TextBlock({required this.title, required this.body});

  static TextBlock fromJson(Map<String, dynamic> j) => TextBlock(
        title: _map(j['title']),
        body: _map(j['body']),
      );
}

class Guide {
  final Map<String, dynamic> title;
  final Map<String, dynamic> intro;
  final List<TextBlock> steps;

  Guide({
    required this.title,
    required this.intro,
    required this.steps,
  });

  static Guide fromJson(Map<String, dynamic> j) => Guide(
        title: _map(j['title']),
        intro: _map(j['intro']),
        steps: _list(j['steps'])
            .map((e) => TextBlock(
                  title: _map(e['title']),
                  body: _map(e['body']),
                ))
            .toList(),
      );
}

class LegalDoc {
  final Map<String, dynamic> title;
  final Map<String, dynamic> updated;
  final Map<String, dynamic> body;
  final List<TextBlock> sections;

  LegalDoc({
    required this.title,
    required this.updated,
    required this.body,
    required this.sections,
  });

  static LegalDoc fromJson(Map<String, dynamic> j) => LegalDoc(
        title: _map(j['title']),
        updated: _map(j['updated']),
        body: _map(j['body']),
        sections: _list(j['sections'])
            .map((e) => TextBlock(title: _map(e['title']), body: _map(e['body'])))
            .toList(),
      );
}

class ContentRepository {
  ContentRepository._();
  static final ContentRepository instance = ContentRepository._();

  bool _loaded = false;

  List<MuscleGroup> muscleGroups = const [];
  Map<String, MuscleGroup> groupsById = {};
  Map<String, Exercise> exercisesByName = {};

  Program? bulkProgram;
  Program? cutProgram;
  TextBlock? warmupTitle;
  List<TextBlock> warmupSteps = const [];
  List<TextBlock> restRules = const [];
  Map<String, dynamic> restTitle = const {};

  List<Meal> meals = const [];
  List<TextBlock> preWorkout = const [];
  List<TextBlock> postWorkout = const [];
  Map<String, dynamic> preWorkoutTitle = const {};
  Map<String, dynamic> postWorkoutTitle = const {};
  List<Supplement> supplements = const [];
  List<Map<String, dynamic>> allowedFoods = const [];
  List<Map<String, dynamic>> avoidFoods = const [];
  Map<String, dynamic> hydrationTitle = const {};
  Map<String, dynamic> hydrationBody = const {};
  List<Map<String, dynamic>> macroRules = const [];

  Guide? bulkGuide;
  Guide? cutGuide;
  TextBlock? trainingTime;
  Map<String, dynamic> mistakesTitle = const {};
  List<Map<String, dynamic>> mistakes = const [];
  Map<String, dynamic> progressTitle = const {};
  List<Map<String, dynamic>> progressItems = const [];

  LegalDoc? privacy;
  LegalDoc? about;
  LegalDoc? contact;
  LegalDoc? disclaimer;

  bool get loaded => _loaded;

  Future<void> load() async {
    if (_loaded) return;
    final ex = await _readJson('assets/data/content/exercises.json');
    final pr = await _readJson('assets/data/content/programs.json');
    final nu = await _readJson('assets/data/content/nutrition.json');
    final gu = await _readJson('assets/data/content/guides.json');
    final le = await _readJson('assets/data/content/legal.json');

    muscleGroups =
        _list(ex['groups']).map(MuscleGroup.fromJson).toList(growable: false);
    groupsById = {for (final g in muscleGroups) g.id: g};
    exercisesByName = {
      for (final g in muscleGroups)
        for (final e in g.items) '${e.name['en']}': e,
    };

    bulkProgram = Program.fromJson(_map(pr['bulking']));
    cutProgram = Program.fromJson(_map(pr['cutting']));

    final warm = _map(pr['warmup']);
    warmupTitle = TextBlock(title: _map(warm['title']), body: const {});
    warmupSteps = _list(warm['steps'])
        .map((e) => TextBlock(title: const {}, body: _map(e)))
        .toList();

    final rest = _map(pr['restAdvice']);
    restTitle = _map(rest['title']);
    restRules = _list(rest['items'])
        .map((e) => TextBlock(title: const {}, body: _map(e)))
        .toList();

    meals = _list(nu['meals']).map(Meal.fromJson).toList(growable: false);

    final pre = _map(nu['preWorkout']);
    preWorkoutTitle = _map(pre['title']);
    preWorkout = _list(pre['items'])
        .map((e) => TextBlock(title: const {}, body: _map(e)))
        .toList();

    final post = _map(nu['postWorkout']);
    postWorkoutTitle = _map(post['title']);
    postWorkout = _list(post['items'])
        .map((e) => TextBlock(title: const {}, body: _map(e)))
        .toList();

    supplements =
        _list(nu['supplements']).map(Supplement.fromJson).toList(growable: false);
    allowedFoods = _list(nu['allowed']).map(_map).toList(growable: false);
    avoidFoods = _list(nu['avoid']).map(_map).toList(growable: false);
    hydrationTitle = _map(_map(nu['hydration'])['title']);
    hydrationBody = _map(_map(nu['hydration'])['body']);

    final macros = _map(nu['macroRules']);
    macroRules = macros.entries
        .map((e) => {'key': e.key, 'value': _map(e.value)})
        .toList(growable: false);

    bulkGuide = Guide.fromJson(_map(gu['bulking']));
    cutGuide = Guide.fromJson(_map(gu['cutting']));

    final tt = _map(gu['trainingTime']);
    trainingTime = TextBlock(title: _map(tt['title']), body: _map(tt['body']));

    final mi = _map(gu['mistakes']);
    mistakesTitle = _map(mi['title']);
    mistakes = _list(mi['items']).map(_map).toList(growable: false);

    final po = _map(gu['progress']);
    progressTitle = _map(po['title']);
    progressItems = _list(po['items']).map(_map).toList(growable: false);

    privacy = LegalDoc.fromJson(_map(le['privacy']));
    about = LegalDoc.fromJson(_map(le['about']));
    contact = LegalDoc.fromJson(_map(le['contact']));
    disclaimer = LegalDoc.fromJson(_map(le['disclaimer']));

    _loaded = true;
  }

  /// Localized display name for a program line, resolved from the exercise DB.
  Exercise? exerciseFor(String ref) => exercisesByName[ref];

  Future<Map<String, dynamic>> _readJson(String path) async {
    try {
      final raw = await rootBundle.loadString(path);
      return json.decode(raw) as Map<String, dynamic>;
    } catch (e) {
      return <String, dynamic>{};
    }
  }
}

// ------------------------------ helpers ------------------------------------

Map<String, dynamic> _map(dynamic value) =>
    value is Map ? value.cast<String, dynamic>() : <String, dynamic>{};

List<Map<String, dynamic>> _list(dynamic value) => value is List
    ? value.whereType<Map>().map((e) => e.cast<String, dynamic>()).toList()
    : <Map<String, dynamic>>[];

int _int(dynamic value, int fallback) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
