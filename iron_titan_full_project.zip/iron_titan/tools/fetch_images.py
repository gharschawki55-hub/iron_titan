import io
import os
import urllib.request

BASE = r"E:\c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2\assets\apps\iron_titan"
IMAGES = os.path.join(BASE, "app", "assets", "images")
os.makedirs(IMAGES, exist_ok=True)

SRC = {
    "hero": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/d2d23966fe76439eb7625ff015aeb460.jpg", 1080),
    "chest": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/b13cf5025e4c41aab99f2a190861b5aa.jpg", 1200),
    "back": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/c4b71b1acd5d40e0ac4afa85c54b99b1.jpg", 1200),
    "legs": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/946309e07bc2499688352a498b19342b.jpg", 1200),
    "nutrition": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/05a198944e494494bde8f56531f75e86.jpg", 1200),
    "cutting": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/09e2757cc8f6425381089cdbd464e85c.jpg", 1200),
    "analysis": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/b8a14788fd7b402bbfa89cc92d73ae3f.jpg", 1200),
    "icon": ("https://asset.seeles.ai/asset/gen/prod/c9e379e6-2e0a-4df3-8c28-e3816f0b1fb2/imagegen/c7e252bb5f004715888c586b7f1b1bab.jpg", 1024),
}

from PIL import Image

for name, (url, target_w) in SRC.items():
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    raw = urllib.request.urlopen(req, timeout=120).read()
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    w, h = img.size
    if w > target_w:
        nh = int(round(h * target_w / w))
        img = img.resize((target_w, nh), Image.LANCZOS)
    out = os.path.join(IMAGES, name + ".jpg")
    img.save(out, "JPEG", quality=82, optimize=True, progressive=True)
    print(name, img.size, round(os.path.getsize(out) / 1024), "KB")
