import 'package:flutter/foundation.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_config.dart';

/// Share sheet + external links, all wrapped so a failure never breaks the app.
class ShareService {
  ShareService._();

  static Future<bool> shareApp(String message) async {
    try {
      await Share.share(message, subject: AppConfig.appName);
      return true;
    } catch (e) {
      debugPrint('ShareService: $e');
      return false;
    }
  }

  static Future<bool> shareTo(String channel, String message) async {
    return shareApp(message);
  }

  static Future<bool> sendEmail({
    required String subject,
    required String body,
  }) async {
    final uri = Uri(
      scheme: 'mailto',
      path: AppConfig.supportEmail,
      query: _encode({'subject': subject, 'body': body}),
    );
    return _launch(uri);
  }

  static Future<bool> openUrl(String url) async => _launch(Uri.parse(url));

  static Future<bool> openPlayStore() => openUrl(AppConfig.playStoreUrl);

  static Future<bool> _launch(Uri uri) async {
    try {
      if (await canLaunchUrl(uri)) {
        return await launchUrl(uri, mode: LaunchMode.externalApplication);
      }
      return false;
    } catch (e) {
      debugPrint('ShareService launch failed: $e');
      return false;
    }
  }

  static String _encode(Map<String, String> params) => params.entries
      .map((e) =>
          '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
      .join('&');
}
