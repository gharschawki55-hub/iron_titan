# Windows (desktop) - notes

The same Dart codebase builds a native Windows desktop app:

```powershell
flutter config --enable-windows-desktop
flutter create --platforms=windows .
flutter build windows --release
```

Output: `build\windows\x64\runner\Release\iron_titan.exe` (+ the `data` and
`*.dll` files next to it).

Install it like any desktop program:

1. Copy the whole `Release` folder (exe + dlls + `data\`) to e.g.
   `C:\Program Files\Iron Titan\`.
2. Right-click `iron_titan.exe` -> "Create shortcut", move the shortcut to the
   Desktop or Start Menu.
3. (Optional) For a single-file installer, use Inno Setup or
   [MSIX Packaging Tool](https://learn.microsoft.com/windows/msix/) on that
   folder - both are free.

## Ads on Windows

Google AdMob is a mobile network: it has **no Windows SDK**. The code already
handles this: `AdsService.platformSupported` is false on desktop, so no ad is
ever requested and the banner slot collapses to zero height. The app is fully
functional on Windows - the layout simply contains no ad.

If you want monetisation on Windows later, the only realistic option is a
desktop ad network (not AdMob) plugged into the same `AdsService`.

## Photo picker on Windows

`image_picker` uses the native Windows file picker; the body analysis works
exactly like on the phone (offline, on-device).
