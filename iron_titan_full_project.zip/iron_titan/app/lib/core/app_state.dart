import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app_config.dart';
import 'l10n.dart';
import 'theme.dart';

/// Global, persisted app state: language, accent color, light/dark, ad consent.
class AppState extends ChangeNotifier {
  static const _kLang = 'it_lang';
  static const _kAccent = 'it_accent';
  static const _kTheme = 'it_theme_mode';
  static const _kConsent = 'it_ad_consent';
  static const _kOnboarded = 'it_onboarded';

  String _language = AppConfig.defaultLanguage;
  String _accentId = 'gold';
  ThemeMode _themeMode = ThemeMode.dark;
  bool _adConsent = false;
  bool _onboarded = false;
  bool _ready = false;

  String get language => _language;
  String get accentId => _accentId;
  AppAccent get accent => accentById(_accentId);
  ThemeMode get themeMode => _themeMode;
  bool get adConsent => _adConsent;
  bool get onboarded => _onboarded;
  bool get ready => _ready;

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      _language = prefs.getString(_kLang) ?? AppConfig.defaultLanguage;
      _accentId = prefs.getString(_kAccent) ?? 'gold';
      final mode = prefs.getString(_kTheme) ?? 'dark';
      _themeMode = mode == 'light'
          ? ThemeMode.light
          : mode == 'system'
              ? ThemeMode.system
              : ThemeMode.dark;
      _adConsent = prefs.getBool(_kConsent) ?? false;
      _onboarded = prefs.getBool(_kOnboarded) ?? false;
    } catch (_) {
      // First run / storage unavailable: keep defaults.
    }
    if (!L10n.codes.contains(_language)) _language = AppConfig.defaultLanguage;
    _ready = true;
    notifyListeners();
  }

  Future<void> setLanguage(String code) async {
    if (!L10n.codes.contains(code) || code == _language) return;
    await L10n.load(code);
    _language = code;
    notifyListeners();
    await _persist((p) => p.setString(_kLang, code));
  }

  Future<void> setAccent(String id) async {
    if (id == _accentId) return;
    _accentId = id;
    notifyListeners();
    await _persist((p) => p.setString(_kAccent, id));
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    if (mode == _themeMode) return;
    _themeMode = mode;
    notifyListeners();
    await _persist((p) => p.setString(_kTheme, mode.name));
  }

  Future<void> setAdConsent(bool value) async {
    _adConsent = value;
    notifyListeners();
    await _persist((p) => p.setBool(_kConsent, value));
  }

  Future<void> markOnboarded() async {
    if (_onboarded) return;
    _onboarded = true;
    notifyListeners();
    await _persist((p) => p.setBool(_kOnboarded, true));
  }

  Future<void> _persist(Future<void> Function(SharedPreferences) action) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await action(prefs);
    } catch (_) {
      // Persisting is best effort; the in-memory value already applied.
    }
  }
}

/// Inherited access to [AppState] without any third-party state package.
class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({
    super.key,
    required AppState state,
    required super.child,
  }) : super(notifier: state);

  static AppState of(BuildContext context) {
    final scope =
        context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope != null, 'AppStateScope is missing above this widget');
    return scope!.notifier!;
  }
}

/// Convenience for the platform "keyboard settings" action.
class KeyboardService {
  static const MethodChannel _channel =
      MethodChannel('com.irontitan.coach/system');

  /// Returns true when the native side actually opened the keyboard settings.
  static Future<bool> openKeyboardSettings() async {
    try {
      final result = await _channel.invokeMethod<bool>('openKeyboardSettings');
      return result ?? false;
    } catch (_) {
      return false;
    }
  }
}
