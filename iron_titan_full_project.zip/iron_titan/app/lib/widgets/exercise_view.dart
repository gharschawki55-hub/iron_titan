import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import 'common.dart';

/// Expandable list of muscle groups with their exercises (sets/reps/rest/cue).
class MuscleGroupsList extends StatelessWidget {
  final List<String> groupIds;

  const MuscleGroupsList({super.key, required this.groupIds});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final groups = <MuscleGroup>[
      for (final id in groupIds)
        if (repo.groupsById[id] != null) repo.groupsById[id]!,
    ];

    return Column(
      children: [
        for (final group in groups)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _GroupCard(group: group),
          ),
      ],
    );
  }
}

class _GroupCard extends StatelessWidget {
  final MuscleGroup group;

  const _GroupCard({required this.group});

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return GoldCard(
      padding: EdgeInsets.zero,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
          childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
          iconColor: accent,
          collapsedIconColor: accent,
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              width: 46,
              height: 46,
              child: Image.asset(
                group.image,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: accent.withOpacity(0.15),
                  child: Icon(Icons.fitness_center, color: accent, size: 20),
                ),
              ),
            ),
          ),
          title: Text(
            context.tr(group.name),
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          subtitle: Text(
            '${group.items.length}',
            style: TextStyle(fontSize: 12, color: accent),
          ),
          children: [
            if (context.tr(group.focus).isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 8, top: 2),
                child: Text(
                  context.tr(group.focus),
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.4,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.7),
                  ),
                ),
              ),
            for (final exercise in group.items) ExerciseTile(exercise: exercise),
          ],
        ),
      ),
    );
  }
}

class ExerciseTile extends StatelessWidget {
  final Exercise exercise;

  const ExerciseTile({super.key, required this.exercise});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            context.tr(exercise.name),
            style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              InfoPill(
                icon: Icons.repeat,
                label: context.t('label_sets'),
                value: '${exercise.sets}',
              ),
              InfoPill(
                icon: Icons.format_list_numbered,
                label: context.t('label_reps'),
                value: exercise.reps,
              ),
              InfoPill(
                icon: Icons.timer_outlined,
                label: context.t('label_rest'),
                value: '${exercise.rest} ${context.t('label_seconds')}',
              ),
              if (exercise.tempo.isNotEmpty)
                InfoPill(
                  icon: Icons.speed,
                  label: context.t('label_tempo'),
                  value: exercise.tempo,
                ),
            ],
          ),
          if (context.tr(exercise.cue).isNotEmpty) ...[
            const SizedBox(height: 8),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.lightbulb_outline, size: 15, color: context.accent),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    context.tr(exercise.cue),
                    style: TextStyle(
                      fontSize: 12.5,
                      height: 1.4,
                      color: Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withOpacity(0.72),
                    ),
                  ),
                ),
              ],
            ),
          ],
          Divider(color: context.accent.withOpacity(0.12), height: 22),
        ],
      ),
    );
  }
}
