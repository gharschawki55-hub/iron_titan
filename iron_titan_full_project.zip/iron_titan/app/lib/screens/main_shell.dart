import 'package:flutter/material.dart';

import '../core/app_config.dart';
import '../core/theme.dart';
import '../widgets/common.dart';
import 'analysis_screen.dart';
import 'bulk_screen.dart';
import 'cut_screen.dart';
import 'home_screen.dart';
import 'legal_screen.dart';
import 'nutrition_screen.dart';
import 'programs_screen.dart';
import 'settings_screen.dart';
import 'timer_screen.dart';

/// Root shell: 4 tabs + side drawer (settings, legal pages, share).
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  static const _pages = <Widget>[
    HomeScreen(),
    ProgramsScreen(embedded: true),
    NutritionScreen(embedded: true),
    AnalysisScreen(embedded: true),
  ];

  String _title(BuildContext context) {
    switch (_index) {
      case 1:
        return context.t('prog_title');
      case 2:
        return context.t('nut_title');
      case 3:
        return context.t('analysis_title');
      default:
        return context.t('app_name');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.fitness_center, size: 20, color: context.accent),
            const SizedBox(width: 8),
            Flexible(child: Text(_title(context), overflow: TextOverflow.ellipsis)),
          ],
        ),
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                context.accent.withOpacity(context.isDark ? 0.22 : 0.26),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      drawer: const AppDrawer(),
      body: IndexedStack(index: _index, children: _pages),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const BannerAdSlot(),
          BottomNavigationBar(
            currentIndex: _index,
            onTap: (i) => setState(() => _index = i),
            items: [
              BottomNavigationBarItem(
                icon: const Icon(Icons.home_outlined),
                activeIcon: const Icon(Icons.home),
                label: context.t('nav_home'),
              ),
              BottomNavigationBarItem(
                icon: const Icon(Icons.calendar_view_week_outlined),
                activeIcon: const Icon(Icons.calendar_view_week),
                label: context.t('nav_programs'),
              ),
              BottomNavigationBarItem(
                icon: const Icon(Icons.restaurant_outlined),
                activeIcon: const Icon(Icons.restaurant),
                label: context.t('nav_nutrition'),
              ),
              BottomNavigationBarItem(
                icon: const Icon(Icons.accessibility_new_outlined),
                activeIcon: const Icon(Icons.accessibility_new),
                label: context.t('nav_analysis'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  void _push(BuildContext context, Widget page) {
    Navigator.of(context).pop();
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return Drawer(
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: context.isDark
                ? [const Color(0xFF121216), const Color(0xFF08080A)]
                : [Colors.white, const Color(0xFFF0EEE8)],
          ),
        ),
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              Container(
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 20),
                decoration: BoxDecoration(
                  border: Border(
                    bottom: BorderSide(color: accent.withOpacity(0.3)),
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.fitness_center, color: accent, size: 26),
                        const SizedBox(width: 10),
                        Text(
                          'IRON TITAN',
                          style: TextStyle(
                            color: accent,
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${context.t('settings_version')} ${AppConfig.version}',
                      style: TextStyle(
                        fontSize: 12,
                        color: Theme.of(context)
                            .colorScheme
                            .onSurface
                            .withOpacity(0.6),
                      ),
                    ),
                  ],
                ),
              ),
              _tile(context, Icons.home, context.t('nav_home'), () {
                Navigator.of(context).pop();
                Navigator.of(context).popUntil((r) => r.isFirst);
              }),
              _tile(context, Icons.trending_up, context.t('section_bulk'),
                  () => _push(context, const BulkScreen())),
              _tile(context, Icons.local_fire_department, context.t('section_cut'),
                  () => _push(context, const CutScreen())),
              _tile(context, Icons.restaurant, context.t('section_nutrition'),
                  () => _push(context, const NutritionScreen())),
              _tile(context, Icons.calendar_view_week, context.t('section_programs'),
                  () => _push(context, const ProgramsScreen())),
              _tile(context, Icons.timer, context.t('section_timer'),
                  () => _push(context, const TimerScreen())),
              _tile(context, Icons.accessibility_new, context.t('section_analysis'),
                  () => _push(context, const AnalysisScreen())),
              Divider(color: accent.withOpacity(0.2), height: 22),
              _tile(context, Icons.settings, context.t('settings_title'),
                  () => _push(context, const SettingsScreen())),
              _tile(context, Icons.shield_outlined, context.t('settings_privacy'),
                  () => _push(context, const PrivacyScreen())),
              _tile(context, Icons.info_outline, context.t('settings_about'),
                  () => _push(context, const AboutScreen())),
              _tile(context, Icons.mail_outline, context.t('settings_contact'),
                  () => _push(context, const ContactScreen())),
              _tile(context, Icons.health_and_safety, context.t('settings_disclaimer'),
                  () => _push(context, const DisclaimerScreen())),
            ],
          ),
        ),
      ),
    );
  }

  Widget _tile(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onTap,
  ) {
    return ListTile(
      leading: Icon(icon, size: 22),
      title: Text(label, style: const TextStyle(fontSize: 15)),
      onTap: onTap,
      dense: true,
      visualDensity: const VisualDensity(vertical: -1),
    );
  }
}
