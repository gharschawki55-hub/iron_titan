import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app.dart';
import 'core/app_state.dart';
import 'core/l10n.dart';
import 'data/content_repository.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Portrait-first on phones; desktop windows are not affected.
  try {
    await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown],
    );
  } catch (_) {}

  final state = AppState();
  await state.load();
  await L10n.load(state.languageCode);
  await ContentRepository.instance.load();

  runApp(IronTitanApp(state: state));
}
