import 'dart:async';
import 'dart:io';

/// Tiny, plugin-free connectivity probe.
///
/// The whole app is offline-first: this probe is ONLY used to decide whether an
/// ad may be requested. When it fails, the app behaves exactly as if there is
/// no network and keeps working normally.
class NetworkProbe {
  NetworkProbe._();

  static bool _cachedValue = false;
  static DateTime _cachedAt = DateTime.fromMillisecondsSinceEpoch(0);
  static const Duration _cacheTtl = Duration(seconds: 20);

  static Future<bool> hasInternet() async {
    final now = DateTime.now();
    if (now.difference(_cachedAt) < _cacheTtl) return _cachedValue;

    var online = false;
    try {
      final result = await InternetAddress.lookup('google.com')
          .timeout(const Duration(seconds: 4));
      online = result.isNotEmpty && result.first.rawAddress.isNotEmpty;
    } catch (_) {
      online = false;
    }

    _cachedValue = online;
    _cachedAt = now;
    return online;
  }

  static void invalidate() {
    _cachedAt = DateTime.fromMillisecondsSinceEpoch(0);
  }
}
