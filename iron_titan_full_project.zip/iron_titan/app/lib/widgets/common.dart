import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../core/app_config.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/ads_service.dart';

/// Context helpers used by every screen.
extension LocalizedWidget on BuildContext {
  String t(String key) => l10n.t(key);

  /// Resolves a `{"ar": "...", "en": "..."}` map for the active language.
  String tr(Map<String, dynamic>? map) =>
      localized(map, Localizations.localeOf(this).languageCode);
}

/// Pushes a full page on top of the shell.
Future<void> pushPage(BuildContext context, Widget page) {
  return Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => page),
  );
}

/// Rounded card with the accent hairline used across the whole app.
class GoldCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final Color? background;

  const GoldCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.onTap,
    this.background,
  });

  @override
  Widget build(BuildContext context) {
    final dark = context.isDark;
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: background ??
            (dark ? const Color(0xFF14141A) : Colors.white),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: context.accent.withOpacity(dark ? 0.30 : 0.35)),
        boxShadow: dark
            ? null
            : [
                BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 14,
                  offset: const Offset(0, 6),
                ),
              ],
      ),
      child: child,
    );

    if (onTap == null) return content;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: content,
    );
  }
}

/// Big, obvious section button with a photo background.
class SectionTile extends StatelessWidget {
  final String image;
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final double height;

  const SectionTile({
    super.key,
    required this.image,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onTap,
    this.height = 148,
  });

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Stack(
        children: [
          SizedBox(
            height: height,
            width: double.infinity,
            child: Image.asset(
              image,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                color: const Color(0xFF14141A),
              ),
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.black.withOpacity(0.35),
                    Colors.black.withOpacity(0.88),
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onTap,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: accent.withOpacity(0.22),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: accent.withOpacity(0.6)),
                        ),
                        child: Icon(icon, color: accent, size: 22),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 0.3,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            subtitle,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.72),
                              fontSize: 12.5,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Small pill used for sets / reps / rest chips.
class InfoPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const InfoPill({
    super.key,
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: accent.withOpacity(0.10),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: accent.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: accent),
          const SizedBox(width: 5),
          Text(
            '$label ',
            style: TextStyle(
              fontSize: 11.5,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: accent,
            ),
          ),
        ],
      ),
    );
  }
}

/// Bullet row used by every guide screen.
class Bullet extends StatelessWidget {
  final String text;
  final IconData icon;

  const Bullet(this.text, {super.key, this.icon = Icons.chevron_right});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: Icon(icon, size: 16, color: context.accent),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 14.5, height: 1.45),
            ),
          ),
        ],
      ),
    );
  }
}

/// Section title with the accent bar.
class SectionHeader extends StatelessWidget {
  final String title;
  final String? action;
  final VoidCallback? onAction;

  const SectionHeader({
    super.key,
    required this.title,
    this.action,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 10),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 20,
            decoration: BoxDecoration(
              color: context.accent,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                letterSpacing: 0.3,
              ),
            ),
          ),
          if (action != null)
            TextButton(onPressed: onAction, child: Text(action!)),
        ],
      ),
    );
  }
}

/// Key/value row used by calculators.
class StatRow extends StatelessWidget {
  final String label;
  final String value;
  final IconData? icon;

  const StatRow({
    super.key,
    required this.label,
    required this.value,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          if (icon != null) ...[
            Icon(icon, size: 18, color: context.accent),
            const SizedBox(width: 8),
          ],
          Expanded(child: Text(label, style: const TextStyle(fontSize: 14))),
          Text(
            value,
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w800,
              color: context.accent,
            ),
          ),
        ],
      ),
    );
  }
}

/// Adaptive banner slot. Renders nothing at all on Windows, without consent,
/// or when the ad fails - the app layout keeps working.
class BannerAdSlot extends StatefulWidget {
  const BannerAdSlot({super.key, this.height = AppConfig.bannerSlotHeight});

  final double height;

  @override
  State<BannerAdSlot> createState() => _BannerAdSlotState();
}

class _BannerAdSlotState extends State<BannerAdSlot> {
  BannerAd? _ad;
  bool _loaded = false;
  bool _disposed = false;
  Timer? _retry;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    if (_disposed) return;
    if (!AdsService.instance.bannerSupported) return;
    try {
      final ad = AdsService.instance.createBanner();
      _ad = ad;
      ad.load().then((_) {
        if (!mounted || _disposed) {
          ad.dispose();
          return;
        }
        setState(() => _loaded = true);
      }).catchError((_) {});
    } catch (_) {
      // Never let a banner prevent the UI from rendering.
    }
    _retry = Timer(const Duration(seconds: 45), () {
      if (mounted && !_loaded) _load();
    });
  }

  @override
  void dispose() {
    _disposed = true;
    _retry?.cancel();
    try {
      _ad?.dispose();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded || _ad is! BannerAd) return const SizedBox.shrink();
    return SizedBox(
      height: widget.height,
      width: double.infinity,
      child: Center(child: AdWidget(ad: _ad as BannerAd)),
    );
  }
}

/// Screen scaffold with the app bar and the luxury background gradient.
class AppPage extends StatelessWidget {
  final String title;
  final Widget child;
  final List<Widget> actions;
  final bool showBack;

  const AppPage({
    super.key,
    required this.title,
    required this.child,
    this.actions = const [],
    this.showBack = true,
  });

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    final dark = context.isDark;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        automaticallyImplyLeading: showBack,
        actions: actions,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                accent.withOpacity(dark ? 0.20 : 0.24),
                Colors.transparent,
              ],
            ),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: dark
                ? [const Color(0xFF0D0D0F), const Color(0xFF070709)]
                : [const Color(0xFFF7F6F2), const Color(0xFFEFEDE7)],
          ),
        ),
        child: SafeArea(top: false, child: child),
      ),
    );
  }
}
