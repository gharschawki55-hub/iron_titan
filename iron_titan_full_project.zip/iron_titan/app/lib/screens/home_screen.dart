import 'package:flutter/material.dart';

import '../core/app_config.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../data/content_repository.dart';
import '../services/ads_service.dart';
import '../services/network_probe.dart';
import '../widgets/common.dart';
import 'analysis_screen.dart';
import 'bulk_screen.dart';
import 'cut_screen.dart';
import 'nutrition_screen.dart';
import 'programs_screen.dart';
import 'timer_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final sections = <_SectionData>[
      _SectionData('assets/images/legs.jpg', Icons.trending_up, 'section_bulk',
          'section_bulk_sub', const BulkScreen()),
      _SectionData('assets/images/cutting.jpg', Icons.local_fire_department,
          'section_cut', 'section_cut_sub', const CutScreen()),
      _SectionData('assets/images/nutrition.jpg', Icons.restaurant,
          'section_nutrition', 'section_nutrition_sub', const NutritionScreen()),
      _SectionData('assets/images/back.jpg', Icons.calendar_view_week,
          'section_programs', 'section_programs_sub', const ProgramsScreen()),
      _SectionData('assets/images/cutting.jpg', Icons.timer, 'section_timer',
          'section_timer_sub', const TimerScreen()),
      _SectionData('assets/images/analysis.jpg', Icons.accessibility_new,
          'section_analysis', 'section_analysis_sub', const AnalysisScreen()),
    ];

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _Hero(),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => pushPage(context, const AnalysisScreen()),
                  icon: const Icon(Icons.camera_alt_outlined, size: 20),
                  label: Text(
                    context.t('home_cta_analyze'),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => pushPage(context, const TimerScreen()),
                  icon: const Icon(Icons.timer_outlined, size: 20),
                  label: Text(
                    context.t('section_timer'),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SectionHeader(title: context.t('home_sections')),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            children: [
              for (var i = 0; i < sections.length; i += 2)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: _tile(context, sections[i])),
                      const SizedBox(width: 12),
                      Expanded(
                        child: i + 1 < sections.length
                            ? _tile(context, sections[i + 1])
                            : const SizedBox.shrink(),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 4),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: RewardCard(tips: repo.mistakes),
        ),
        const SizedBox(height: 16),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Icon(Icons.wifi_off,
                  size: 15, color: context.accent.withOpacity(0.8)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  context.t('home_offline_note'),
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _tile(BuildContext context, _SectionData data) {
    return SectionTile(
      image: data.image,
      icon: data.icon,
      title: context.t(data.titleKey),
      subtitle: context.t(data.subtitleKey),
      height: 150,
      onTap: () => pushPage(context, data.page),
    );
  }
}

class _SectionData {
  final String image;
  final IconData icon;
  final String titleKey;
  final String subtitleKey;
  final Widget page;

  _SectionData(this.image, this.icon, this.titleKey, this.subtitleKey, this.page);
}

class _Hero extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return SizedBox(
      height: 400,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/hero.jpg',
            fit: BoxFit.cover,
            alignment: Alignment.topCenter,
            errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF101014)),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0x99000000), Color(0x22000000), Color(0xF2070709)],
                stops: [0, 0.45, 1],
              ),
            ),
          ),
          Positioned(
            left: 18,
            right: 18,
            bottom: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.18),
                    border: Border.all(color: accent.withOpacity(0.8)),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    context.t('app_tagline').toUpperCase(),
                    style: TextStyle(
                      color: accent,
                      fontSize: 10.5,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  context.t('home_hero_title'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 34,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.4,
                    height: 1.05,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  context.t('home_hero_sub'),
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.78),
                    fontSize: 13.5,
                    height: 1.4,
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: () => pushPage(context, const ProgramsScreen()),
                    icon: const Icon(Icons.play_arrow_rounded, size: 22),
                    label: Text(context.t('home_cta_start')),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Opt-in rewarded video (30 s) that unlocks the advanced coach tip.
/// Offline users still get the tip: the app must never depend on the network.
class RewardCard extends StatefulWidget {
  final List<Map<String, dynamic>> tips;

  const RewardCard({super.key, required this.tips});

  @override
  State<RewardCard> createState() => _RewardCardState();
}

class _RewardCardState extends State<RewardCard> {
  bool _busy = false;

  Future<void> _watch() async {
    if (_busy) return;
    setState(() => _busy = true);
    final state = AppStateScope.of(context);

    final online = await NetworkProbe.hasInternet();
    if (!online) {
      if (mounted) {
        _snack(context.t('ad_offline'));
        _showTip();
      }
      if (mounted) setState(() => _busy = false);
      return;
    }

    if (!state.adConsent || !AdsService.platformSupported) {
      if (mounted) {
        _snack(context.t('ad_not_available'));
        _showTip();
      }
      if (mounted) setState(() => _busy = false);
      return;
    }

    final earned = await AdsService.instance.showRewarded();
    if (!mounted) return;
    setState(() => _busy = false);
    if (earned) {
      _showTip();
    } else {
      _snack(context.t('ad_not_available'));
    }
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  void _showTip() {
    if (widget.tips.isEmpty) return;
    final start = DateTime.now().day % widget.tips.length;
    final selection = <Map<String, dynamic>>[
      for (var i = 0; i < 3 && i < widget.tips.length; i++)
        widget.tips[(start + i) % widget.tips.length],
    ];
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.t('home_reward_title')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final tip in selection)
              Bullet(ctx.tr(tip), icon: Icons.check_circle_outline),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(ctx.t('action_close')),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return GoldCard(
      padding: const EdgeInsets.all(18),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.14),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: accent.withOpacity(0.5)),
            ),
            child: Icon(Icons.workspace_premium, color: accent),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.t('home_reward_title'),
                  style: const TextStyle(
                    fontSize: 15.5,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  context.t('home_reward_sub'),
                  style: TextStyle(
                    fontSize: 12,
                    height: 1.35,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.66),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 42,
                  child: FilledButton.icon(
                    onPressed: _busy ? null : _watch,
                    icon: _busy
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.play_circle_outline, size: 18),
                    label: Text(
                      context.t('home_watch_ad'),
                      style: const TextStyle(fontSize: 13.5),
                    ),
                    style: FilledButton.styleFrom(
                      backgroundColor: accent,
                      foregroundColor: onColor(accent),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Kept for the "powered by" footer when the owner wants it.
class VersionFooter extends StatelessWidget {
  const VersionFooter({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        '${AppConfig.appName} · v${AppConfig.version}',
        style: TextStyle(
          fontSize: 11,
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
        ),
      ),
    );
  }
}
