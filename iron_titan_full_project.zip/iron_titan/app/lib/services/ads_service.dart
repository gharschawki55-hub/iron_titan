import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../core/app_config.dart';
import 'network_probe.dart';

/// Central AdMob wrapper.
///
/// Safety rules implemented here:
///  * ads exist only on Android and iOS (Windows/desktop silently skips them);
///  * nothing loads without user consent;
///  * nothing loads or shows without an internet connection;
///  * an interstitial cannot appear twice inside [AppConfig.interstitialMinGap];
///  * every failure is swallowed so the app never blocks on an ad.
class AdsService {
  AdsService._();
  static final AdsService instance = AdsService._();

  bool _initialized = false;
  bool _initFailed = false;

  InterstitialAd? _interstitial;
  RewardedAd? _rewarded;
  bool _loadingInterstitial = false;
  bool _loadingRewarded = false;

  DateTime? _lastInterstitialAt;

  bool _consent = false;
  bool get consent => _consent;
  set consent(bool value) {
    _consent = value;
    if (value && _initialized) {
      _loadInterstitial();
      _loadRewarded();
    }
  }

  static bool get platformSupported =>
      !kIsWeb &&
      (defaultTargetPlatform == TargetPlatform.android ||
          defaultTargetPlatform == TargetPlatform.iOS);

  bool get isInitialized => _initialized;
  bool get bannerSupported => platformSupported && AppConfig.adsEnabled && _consent;
  bool get rewardedReady => _rewarded != null;

  Future<void> init() async {
    if (!AppConfig.adsEnabled || !platformSupported) return;
    if (_initialized || _initFailed) return;
    try {
      await MobileAds.instance.initialize();
      MobileAds.instance.updateRequestConfiguration(
        RequestConfiguration(
          testDeviceIds: const <String>[],
          tagForChildDirectedTreatment: TagForChildDirectedTreatment.unspecified,
        ),
      );
      _initialized = true;
      if (_consent) {
        _loadInterstitial();
        _loadRewarded();
      }
    } catch (e) {
      _initFailed = true;
      debugPrint('AdsService: init failed ($e)');
    }
  }

  // ------------------------------------------------------------------ banner
  BannerAd createBanner() => BannerAd(
        adUnitId: AppConfig.bannerUnitId,
        size: AdSize.banner,
        request: const AdRequest(),
        listener: BannerAdListener(
          onAdFailedToLoad: (ad, error) {
            ad.dispose();
            debugPrint('AdsService: banner failed (${error.code})');
          },
        ),
      );

  // ---------------------------------------------------------- interstitial
  void _loadInterstitial() {
    if (!_initialized || !_consent || _loadingInterstitial || _interstitial != null) {
      return;
    }
    _loadingInterstitial = true;
    InterstitialAd.load(
      adUnitId: AppConfig.interstitialUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingInterstitial = false;
          _interstitial = ad;
        },
        onAdFailedToLoad: (error) {
          _loadingInterstitial = false;
          _interstitial = null;
          debugPrint('AdsService: interstitial failed (${error.code})');
        },
      ),
    );
  }

  /// The 15 second launch video. Never blocks the UI: returns false when there
  /// is no network, no consent, or no fill.
  Future<bool> maybeShowInterstitial({bool force = false}) async {
    if (!AppConfig.adsEnabled || !platformSupported) return false;
    if (!_consent) return false;
    if (!await NetworkProbe.hasInternet()) return false;
    if (!_initialized) return false;

    if (!force) {
      final last = _lastInterstitialAt;
      if (last != null &&
          DateTime.now().difference(last) < AppConfig.interstitialMinGap) {
        return false;
      }
    }

    if (_interstitial == null) {
      _loadInterstitial();
      return false;
    }

    final ad = _interstitial!;
    _interstitial = null;
    _lastInterstitialAt = DateTime.now();

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _loadInterstitial();
      },
    );
    await ad.show();
    return true;
  }

  // -------------------------------------------------------------- rewarded
  void _loadRewarded() {
    if (!_initialized || !_consent || _loadingRewarded || _rewarded != null) {
      return;
    }
    _loadingRewarded = true;
    RewardedAd.load(
      adUnitId: AppConfig.rewardedUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          _loadingRewarded = false;
          _rewarded = ad;
        },
        onAdFailedToLoad: (error) {
          _loadingRewarded = false;
          _rewarded = null;
          debugPrint('AdsService: rewarded failed (${error.code})');
        },
      ),
    );
  }

  Future<void> preloadRewarded() async {
    if (!_consent) return;
    if (!await NetworkProbe.hasInternet()) return;
    _loadRewarded();
  }

  /// The 30 second opt-in video. Returns true only when the reward was earned.
  Future<bool> showRewarded() async {
    if (!AppConfig.adsEnabled || !platformSupported || !_consent) return false;
    if (!await NetworkProbe.hasInternet()) return false;
    if (!_initialized) return false;

    if (_rewarded == null) {
      _loadRewarded();
      return false;
    }

    final ad = _rewarded!;
    _rewarded = null;
    var earned = false;

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _loadRewarded();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _loadRewarded();
      },
    );

    await ad.show(onUserEarnedReward: (AdWithoutView _, RewardItem reward) {
      earned = true;
    });
    return earned;
  }

  // -------------------------------------------------------------- lifecycle
  void disposeBanner(BannerAd? ad) => ad?.dispose();
}
