import 'package:flutter/foundation.dart';

/// ============================================================================
///  IRON TITAN - central configuration
///  Everything the store owner may need to change lives in this single file.
/// ============================================================================
class AppConfig {
  AppConfig._();

  // --------------------------------------------------------------------------
  // 1) ADS - GOOGLE ADMOB
  //    Replace every id below with your own id from https://apps.admob.com
  //    The values shipped here are Google's OFFICIAL TEST ids (they never earn
  //    money and never violate policy). See README.md, section "AdMob".
  // --------------------------------------------------------------------------

  /// Master switch. Set to false to ship an app without any ad.
  static const bool adsEnabled = true;

  /// AdMob **App ID** (format: ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY)
  /// Android: android/app/src/main/AndroidManifest.xml  -> meta-data APPLICATION_ID
  /// iOS    : ios/Runner/Info.plist                     -> GADApplicationIdentifier
  static const String androidAppId = 'ca-app-pub-3940256099942544~3347511713';
  static const String iosAppId = 'ca-app-pub-3940256099942544~1458002511';

  /// Interstitial (video, ~15 s) - shown once when the app opens.
  static const String _androidInterstitial = 'ca-app-pub-3940256099942544/1033173712';
  static const String _iosInterstitial = 'ca-app-pub-3940256099942544/4411468910';

  /// Rewarded video (~30 s) - the highest paying format, user opts in.
  static const String _androidRewarded = 'ca-app-pub-3940256099942544/5224354917';
  static const String _iosRewarded = 'ca-app-pub-3940256099942544/1712485313';

  /// Adaptive banner pinned at the bottom of the app.
  static const String _androidBanner = 'ca-app-pub-3940256099942544/6300978111';
  static const String _iosBanner = 'ca-app-pub-3940256099942544/2934735716';

  static String get interstitialUnitId =>
      _pick(_androidInterstitial, _iosInterstitial);
  static String get rewardedUnitId => _pick(_androidRewarded, _iosRewarded);
  static String get bannerUnitId => _pick(_androidBanner, _iosBanner);

  static String _pick(String android, String ios) =>
      defaultTargetPlatform == TargetPlatform.iOS ? ios : android;

  /// Minimum delay between two interstitial ads (keeps the UX and the policy
  /// safe: no ad on every tap).
  static const Duration interstitialMinGap = Duration(minutes: 3);

  /// Show the launch interstitial once the user has granted ad consent.
  static const bool interstitialOnLaunch = true;

  /// Banner height slot reserved at the bottom of the scaffold.
  static const double bannerSlotHeight = 52;

  // --------------------------------------------------------------------------
  // 2) IDENTITY / LEGAL
  // --------------------------------------------------------------------------

  static const String appName = 'Iron Titan - Weightlifting Coach';
  static const String version = '1.0.0';
  static const String buildNumber = '1';

  /// Put your real support address here (used by "Contact us").
  static const String supportEmail = 'support@irontitan.app';
  static const String websiteUrl = 'https://irontitan.app';
  static const String playStoreUrl =
      'https://play.google.com/store/apps/details?id=com.irontitan.coach';
  static const String appStoreUrl = 'https://apps.apple.com/app/id0000000000';

  // --------------------------------------------------------------------------
  // 3) OPTIONAL CLOUD VISION (body photo analysis)
  //    The app is 100% functional offline with the built-in coaching engine.
  //    If you want true photographic muscle detection, host a small vision
  //    endpoint and paste it below; the app will call it only when online and
  //    silently fall back to the offline engine otherwise.
  // --------------------------------------------------------------------------
  static const String visionEndpoint = ''; // e.g. https://api.mysite.com/analyze
  static const String visionApiKey = '';
  static bool get visionEnabled => visionEndpoint.isNotEmpty;

  // --------------------------------------------------------------------------
  // 4) CONTENT
  // --------------------------------------------------------------------------
  static const String defaultLanguage = 'ar';

  /// Languages that ship with a full UI translation (one JSON file each).
  /// Add any new language: drop assets/data/i18n/<code>.json, done.
  static const List<String> uiLanguages = [
    'ar', 'en', 'fr', 'es', 'de', 'it', 'tr', 'ru', 'zh', 'hi', 'pt', 'ur',
  ];

  /// Longer editorial guides are authored in these languages; other languages
  /// fall back to English for the long articles (the UI stays translated).
  static const List<String> articleLanguages = ['ar', 'en', 'fr'];
}
