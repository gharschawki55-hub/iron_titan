import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import 'common.dart';

/// Card showing a localized title + paragraph.
class ParagraphCard extends StatelessWidget {
  final String title;
  final String body;
  final IconData? icon;

  const ParagraphCard({
    super.key,
    required this.title,
    required this.body,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return GoldCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (icon != null) ...[
                Icon(icon, size: 18, color: accent),
                const SizedBox(width: 8),
              ],
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),
          if (body.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(body, style: const TextStyle(fontSize: 13.5, height: 1.55)),
          ],
        ],
      ),
    );
  }
}

/// Numbered list of guide steps.
class NumberedSteps extends StatelessWidget {
  final List<TextBlock> steps;

  const NumberedSteps({super.key, required this.steps});

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    return Column(
      children: [
        for (var i = 0; i < steps.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GoldCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 28,
                    height: 28,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.16),
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(color: accent.withOpacity(0.6)),
                    ),
                    child: Text(
                      '${i + 1}',
                      style: TextStyle(
                        color: accent,
                        fontWeight: FontWeight.w900,
                        fontSize: 13,
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (context.tr(steps[i].title).isNotEmpty)
                          Text(
                            context.tr(steps[i].title),
                            style: const TextStyle(
                              fontSize: 14.5,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        if (context.tr(steps[i].body).isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Text(
                            context.tr(steps[i].body),
                            style: const TextStyle(fontSize: 13, height: 1.5),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

/// Simple bulleted card for short localized maps.
class BulletCard extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> items;
  final IconData icon;

  const BulletCard({
    super.key,
    required this.title,
    required this.items,
    this.icon = Icons.check_circle_outline,
  });

  @override
  Widget build(BuildContext context) {
    return GoldCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          for (final item in items) Bullet(context.tr(item), icon: icon),
        ],
      ),
    );
  }
}
