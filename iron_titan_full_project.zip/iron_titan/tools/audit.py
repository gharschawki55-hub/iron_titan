"""Static audit for the Iron Titan Flutter project.

Checks (no Flutter SDK required):
  1. every t('key') / tN('key', ...) used in lib/ exists in en.json and in every shipped locale
  2. every asset path referenced from Dart exists on disk
  3. content JSON structure used by ContentRepository is present
  4. program item refs resolve to an exercise english name
  5. image fields inside content JSON point to existing files
  6. relative imports resolve
  7. json files are valid json
"""

import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
APP = os.path.join(ROOT, "app")
LIB = os.path.join(APP, "lib")
ASSETS = os.path.join(APP, "assets")
I18N = os.path.join(ASSETS, "data", "i18n")
CONTENT = os.path.join(ASSETS, "data", "content")

problems = []


def fail(msg):
    problems.append(msg)


def dart_files():
    out = []
    for base, _, files in os.walk(LIB):
        for f in files:
            if f.endswith(".dart"):
                out.append(os.path.join(base, f))
    return sorted(out)


darts = dart_files()
if not darts:
    fail("no dart files found in lib/")
    print("\n".join(problems))
    sys.exit(1)

sources = {}
for path in darts:
    with open(path, "r", encoding="utf-8") as fh:
        sources[path] = fh.read()
all_source = "\n".join(sources.values())

# ---------------------------------------------------------------- 1. i18n keys
key_re = re.compile(r"\btN?\(\s*'([^'\\]+)'")
used = {}
for path, src in sources.items():
    for key in key_re.findall(src):
        used.setdefault(key, set()).add(os.path.relpath(path, APP))

locales = {}
for name in sorted(os.listdir(I18N)):
    if not name.endswith(".json"):
        continue
    code = name[:-5]
    try:
        with open(os.path.join(I18N, name), "r", encoding="utf-8") as fh:
            locales[code] = json.load(fh)
    except Exception as exc:  # noqa: BLE001
        fail(f"i18n {name}: invalid json ({exc})")

if "en" not in locales:
    fail("missing en.json")
else:
    english = locales["en"]
    for key, where in sorted(used.items()):
        if key not in english:
            fail("key '%s' used in %s but missing from en.json"
                 % (key, ", ".join(sorted(where))))
    for code, data in sorted(locales.items()):
        missing = [k for k in used if k not in data]
        if missing:
            fail("%s.json missing %d used key(s): %s"
                 % (code, len(missing), ", ".join(missing[:12])))
    unused = [k for k in english
              if k not in used
              and "'%s'" % k not in all_source
              and '"%s"' % k not in all_source]
    if unused:
        print("note: %d key(s) present in every locale but never referenced: %s"
              % (len(unused), ", ".join(unused)))

# ------------------------------------------------------------ 2. asset paths
asset_re = re.compile(r"['\"](assets/[^'\"]+)['\"]")
for path, src in sources.items():
    for ref in sorted(set(asset_re.findall(src))):
        if "$" in ref:
            continue  # runtime-interpolated path, cannot be resolved statically
        full = os.path.join(APP, ref.replace("/", os.sep))
        if ref.endswith("/"):
            if not os.path.isdir(full):
                fail("missing asset dir %s (in %s)"
                     % (ref, os.path.relpath(path, APP)))
        elif not os.path.exists(full):
            fail("missing asset %s (in %s)"
                 % (ref, os.path.relpath(path, APP)))

# ------------------------------------------------------- 3/4/5. content json
expected_top = {
    "exercises.json": ["groups"],
    "programs.json": ["bulking", "cutting", "warmup", "restAdvice"],
    "nutrition.json": ["meals", "preWorkout", "postWorkout", "supplements",
                       "allowed", "avoid", "hydration", "macroRules"],
    "guides.json": ["bulking", "cutting", "trainingTime", "mistakes", "progress"],
    "legal.json": ["privacy", "about", "contact", "disclaimer"],
}

content = {}
for name, keys in expected_top.items():
    path = os.path.join(CONTENT, name)
    if not os.path.exists(path):
        fail("missing content file %s" % name)
        continue
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as exc:  # noqa: BLE001
        fail("%s: invalid json (%s)" % (name, exc))
        continue
    content[name] = data
    for k in keys:
        if k not in data:
            fail("%s: missing top level key '%s'" % (name, k))

images_dir = os.path.join(ASSETS, "images")
disk_images = set(os.listdir(images_dir)) if os.path.isdir(images_dir) else set()


def check_image(value, where):
    if not isinstance(value, str) or not value:
        return
    base = os.path.basename(value)
    if base not in disk_images:
        fail("%s: image '%s' not present in assets/images" % (where, value))


english_names = set()
for group in content.get("exercises.json", {}).get("groups", []):
    check_image(group.get("image"), "exercises/%s" % group.get("id"))
    for item in group.get("items", []):
        name = item.get("name") or {}
        if isinstance(name, dict) and "en" in name:
            english_names.add(name["en"])
        else:
            fail("exercises/%s: exercise without english name" % group.get("id"))

for section in ("bulking", "cutting"):
    prog = content.get("programs.json", {}).get(section) or {}
    check_image(prog.get("image"), "programs/%s" % section)
    for day in prog.get("days", []):
        if not day.get("label"):
            fail("programs/%s day '%s' has no label" % (section, day.get("id")))
        check_image(day.get("image"), "programs/%s/%s" % (section, day.get("id")))
        for item in day.get("items", []):
            ref = item.get("ref")
            if ref not in english_names:
                fail("programs/%s/%s: ref '%s' not found in exercises.json"
                     % (section, day.get("id"), ref))

for meal in content.get("nutrition.json", {}).get("meals", []):
    check_image(meal.get("image"), "nutrition/meal/%s" % meal.get("id"))

# --------------------------------------------------------------- 6. imports
import_re = re.compile(r"^\s*import\s+'([^']+)';", re.MULTILINE)
for path, src in sources.items():
    for ref in import_re.findall(src):
        if ref.startswith(("dart:", "package:")):
            continue
        target = os.path.normpath(os.path.join(os.path.dirname(path), ref))
        if not os.path.exists(target):
            fail("broken import '%s' in %s" % (ref, os.path.relpath(path, APP)))

# ------------------------------------------------------- 7. brace/paren sanity
def strip_comments_and_strings(src):
    out = []
    i = 0
    n = len(src)
    while i < n:
        ch = src[i]
        if ch == "/" and i + 1 < n and src[i + 1] == "/":
            while i < n and src[i] != "\n":
                i += 1
        elif ch == "/" and i + 1 < n and src[i + 1] == "*":
            i += 2
            while i + 1 < n and not (src[i] == "*" and src[i + 1] == "/"):
                i += 1
            i += 2
        elif ch in ("'", '"'):
            quote = ch
            triple = src[i:i + 3] == quote * 3
            i += 3 if triple else 1
            while i < n:
                if src[i] == "\\":
                    i += 2
                    continue
                if triple and src[i:i + 3] == quote * 3:
                    i += 3
                    break
                if not triple and src[i] == quote:
                    i += 1
                    break
                i += 1
        else:
            out.append(ch)
            i += 1
    return "".join(out)


CLEAN = {p: strip_comments_and_strings(s) for p, s in sources.items()}
for path, src in CLEAN.items():
    for open_ch, close_ch in (("{", "}"), ("(", ")"), ("[", "]")):
        if src.count(open_ch) != src.count(close_ch):
            fail("%s: unbalanced %s%s (%d vs %d)"
                 % (os.path.relpath(path, APP), open_ch, close_ch,
                    src.count(open_ch), src.count(close_ch)))

# ------------------------------------------------ 8. num.clamp -> int typing
# `num.clamp` is typed `num`: assigning it straight to an int does not compile.
clamp_re = re.compile(r"\.clamp\([^)]*\)")
for path, src in CLEAN.items():
    lines = src.splitlines()
    for lineno, line in enumerate(lines, start=1):
        for hit in clamp_re.findall(line):
            tail = line.split(hit, 1)[1].lstrip()
            if not tail:
                # chained call on the next line
                nxt = ""
                for probe in lines[lineno:lineno + 2]:
                    if probe.strip():
                        nxt = probe.strip()
                        break
                tail = nxt
            if not (tail.startswith(".toInt(") or tail.startswith(".toDouble(")
                    or tail.startswith(".round(")):
                fail("%s:%d: .clamp() result used without toInt()/toDouble() "
                     "(num is not int)" % (os.path.relpath(path, APP), lineno))

print("dart files: %d | locales: %d | i18n keys used: %d"
      % (len(darts), len(locales), len(used)))
if problems:
    print("\nPROBLEMS (%d):" % len(problems))
    for p in problems:
        print(" - " + p)
    sys.exit(1)
print("AUDIT OK")
