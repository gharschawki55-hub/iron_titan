import 'package:flutter/material.dart';

import 'core/app_config.dart';
import 'core/app_state.dart';
import 'core/l10n.dart';
import 'core/theme.dart';
import 'screens/bootstrap_gate.dart';

class IronTitanApp extends StatelessWidget {
  final AppState state;

  const IronTitanApp({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      state: state,
      child: AnimatedBuilder(
        animation: state,
        builder: (context, _) {
          return MaterialApp(
            title: AppConfig.appName,
            debugShowCheckedModeBanner: false,
            theme: buildTheme(state.accent, Brightness.light),
            darkTheme: buildTheme(state.accent, Brightness.dark),
            themeMode: state.themeMode,
            locale: Locale(state.language),
            supportedLocales: L10n.supportedLocales,
            localizationsDelegates: L10n.delegates,
            localeResolutionCallback: (_, __) => Locale(state.language),
            // The bundled translations drive the layout direction as well, so
            // Arabic / Urdu get a real RTL interface (no GlobalMaterialLocalizations
            // is shipped: it would add several MB for no extra content).
            builder: (context, child) => Directionality(
              textDirection: L10n.isRtl(state.language)
                  ? TextDirection.rtl
                  : TextDirection.ltr,
              child: child ?? const SizedBox.shrink(),
            ),
            home: const BootstrapGate(),
          );
        },
      ),
    );
  }
}
