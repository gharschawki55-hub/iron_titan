import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import '../widgets/common.dart';
import '../widgets/content_views.dart';

/// Nutrition tab: full meal plan, pre/post workout, supplements, do/don't lists.
class NutritionScreen extends StatelessWidget {
  final bool embedded;

  const NutritionScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;

    final body = ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
      children: [
        ParagraphCard(
          title: context.t('nut_title'),
          body: context.t('nut_sub'),
          icon: Icons.restaurant_menu,
        ),
        const SizedBox(height: 16),
        for (final meal in repo.meals) ...[
          _MealCard(meal: meal),
          const SizedBox(height: 14),
        ],
        if (repo.preWorkout.isNotEmpty) ...[
          SectionHeader(title: context.tr(repo.preWorkoutTitle)),
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final block in repo.preWorkout)
                  Bullet(context.tr(block.body), icon: Icons.bolt),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
        if (repo.postWorkout.isNotEmpty) ...[
          SectionHeader(title: context.tr(repo.postWorkoutTitle)),
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final block in repo.postWorkout)
                  Bullet(context.tr(block.body), icon: Icons.battery_charging_full),
              ],
            ),
          ),
          const SizedBox(height: 16),
        ],
        SectionHeader(title: context.t('nut_supp')),
        for (final supplement in repo.supplements)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: GoldCard(
              padding: const EdgeInsets.all(14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.medication_outlined,
                      size: 20, color: context.accent),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                context.tr(supplement.name),
                                style: const TextStyle(
                                  fontSize: 14.5,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            Text(
                              context.tr(supplement.dose),
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: context.accent,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Text(
                          context.tr(supplement.note),
                          style: const TextStyle(fontSize: 12.5, height: 1.45),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 8),
        if (repo.allowedFoods.isNotEmpty)
          BulletCard(
            title: context.t('nut_allowed'),
            items: repo.allowedFoods,
            icon: Icons.check_circle_outline,
          ),
        const SizedBox(height: 14),
        if (repo.avoidFoods.isNotEmpty)
          BulletCard(
            title: context.t('nut_avoid'),
            items: repo.avoidFoods,
            icon: Icons.block,
          ),
        const SizedBox(height: 14),
        if (repo.hydrationBody.isNotEmpty)
          ParagraphCard(
            title: context.tr(repo.hydrationTitle),
            body: context.tr(repo.hydrationBody),
            icon: Icons.water_drop_outlined,
          ),
      ],
    );

    if (embedded) return body;
    return AppPage(title: context.t('nut_title'), child: body);
  }
}

class _MealCard extends StatelessWidget {
  final Meal meal;

  const _MealCard({required this.meal});

  @override
  Widget build(BuildContext context) {
    final accent = context.accent;
    final total =
        meal.items.fold<int>(0, (sum, item) => sum + (item.kcal));
    return GoldCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
            child: SizedBox(
              height: 120,
              width: double.infinity,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset(
                    meal.image,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const ColoredBox(color: Color(0xFF14141A)),
                  ),
                  const DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [Color(0xE6000000), Color(0x22000000)],
                      ),
                    ),
                  ),
                  Positioned(
                    left: 14,
                    right: 14,
                    bottom: 10,
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            context.tr(meal.title),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ),
                        if (total > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: accent.withOpacity(0.22),
                              borderRadius: BorderRadius.circular(20),
                              border:
                                  Border.all(color: accent.withOpacity(0.7)),
                            ),
                            child: Text(
                              '$total ${context.t('label_calories')}',
                              style: TextStyle(
                                color: accent,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.tr(meal.time),
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                    color: accent,
                  ),
                ),
                const SizedBox(height: 8),
                for (final item in meal.items)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              color: accent,
                              shape: BoxShape.circle,
                            ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            context.tr(item.name),
                            style: const TextStyle(fontSize: 13.5),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          context.tr(item.amount),
                          style: TextStyle(
                            fontSize: 11.5,
                            color: Theme.of(context)
                                .colorScheme
                                .onSurface
                                .withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                  ),
                if (context.tr(meal.note).isNotEmpty) ...[
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: accent.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: accent.withOpacity(0.25)),
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.info_outline, size: 15, color: accent),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            context.tr(meal.note),
                            style:
                                const TextStyle(fontSize: 12.5, height: 1.45),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
