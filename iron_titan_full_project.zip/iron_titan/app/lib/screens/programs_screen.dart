import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/content_repository.dart';
import '../widgets/common.dart';
import '../widgets/content_views.dart';
import 'timer_screen.dart';

/// Weekly programs: mass split, cutting split, warm-up and rest rules.
class ProgramsScreen extends StatelessWidget {
  final bool embedded;

  const ProgramsScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final content = Column(
      children: [
        Container(
          margin: const EdgeInsets.fromLTRB(16, 14, 16, 6),
          decoration: BoxDecoration(
            color: context.accent.withOpacity(0.10),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: context.accent.withOpacity(0.35)),
          ),
          child: TabBar(
            indicator: BoxDecoration(
              color: context.accent,
              borderRadius: BorderRadius.circular(12),
            ),
            indicatorSize: TabBarIndicatorSize.tab,
            indicatorPadding: const EdgeInsets.all(4),
            labelColor: onColor(context.accent),
            unselectedLabelColor: Theme.of(context).colorScheme.onSurface,
            labelStyle:
                const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5),
            dividerColor: Colors.transparent,
            tabs: [
              Tab(text: context.t('prog_bulk')),
              Tab(text: context.t('prog_cut')),
            ],
          ),
        ),
        Expanded(
          child: TabBarView(
            children: [
              _ProgramList(program: repo.bulkProgram),
              _ProgramList(program: repo.cutProgram),
            ],
          ),
        ),
      ],
    );

    final body = DefaultTabController(length: 2, child: content);

    if (embedded) return body;
    return AppPage(title: context.t('prog_title'), child: body);
  }
}

class _ProgramList extends StatelessWidget {
  final Program? program;

  const _ProgramList({required this.program});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    if (program == null) {
      return Center(child: Text(context.t('common_loading')));
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
      children: [
        ParagraphCard(
          title: context.tr(program!.title),
          body: context.tr(program!.subtitle),
          icon: Icons.calendar_month,
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 50,
          child: ElevatedButton.icon(
            onPressed: () => pushPage(context, const TimerScreen()),
            icon: const Icon(Icons.timer_outlined, size: 20),
            label: Text(context.t('timer_title')),
          ),
        ),
        const SizedBox(height: 18),
        if (repo.warmupTitle != null && repo.warmupSteps.isNotEmpty) ...[
          GoldCard(
            child: Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                tilePadding: EdgeInsets.zero,
                childrenPadding: const EdgeInsets.only(top: 4),
                iconColor: context.accent,
                collapsedIconColor: context.accent,
                title: Text(
                  context.tr(repo.warmupTitle!.title),
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                children: [
                  for (final step in repo.warmupSteps)
                    Bullet(context.tr(step.body), icon: Icons.check),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
        ],
        for (final day in program!.days)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: _DayCard(day: day),
          ),
        const SizedBox(height: 6),
        if (repo.restRules.isNotEmpty)
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.tr(repo.restTitle),
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 8),
                for (final rule in repo.restRules)
                  Bullet(context.tr(rule.body), icon: Icons.hotel),
              ],
            ),
          ),
      ],
    );
  }
}

class _DayCard extends StatelessWidget {
  final ProgramDay day;

  const _DayCard({required this.day});

  @override
  Widget build(BuildContext context) {
    final repo = ContentRepository.instance;
    final accent = context.accent;
    final title = context.tr(day.label);

    return GoldCard(
      padding: EdgeInsets.zero,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
          iconColor: accent,
          collapsedIconColor: accent,
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: SizedBox(
              width: 46,
              height: 46,
              child: Image.asset(
                day.image,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                  color: accent.withOpacity(0.15),
                  child: Icon(Icons.fitness_center, color: accent, size: 20),
                ),
              ),
            ),
          ),
          title: Text(
            title,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          ),
          subtitle: Text(
            day.items.isEmpty
                ? context.t('prog_rest')
                : '${day.items.length}',
            style: TextStyle(fontSize: 12, color: accent),
          ),
          children: [
            if (day.items.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  context.t('prog_rest'),
                  style: const TextStyle(fontSize: 13),
                ),
              )
            else
              for (final item in day.items)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        repo.exerciseFor(item.ref) != null
                            ? context.tr(repo.exerciseFor(item.ref)!.name)
                            : item.ref,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 5),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          InfoPill(
                            icon: Icons.repeat,
                            label: context.t('label_sets'),
                            value: '${item.sets}',
                          ),
                          InfoPill(
                            icon: Icons.format_list_numbered,
                            label: context.t('label_reps'),
                            value: item.reps,
                          ),
                          InfoPill(
                            icon: Icons.timer_outlined,
                            label: context.t('label_rest'),
                            value: '${item.rest} ${context.t('label_seconds')}',
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
          ],
        ),
      ),
    );
  }
}

extension _Let<T> on T {
  R let<R>(R Function(T) block) => block(this);
}
