import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_config.dart';

/// Runtime translation bundle.
///
/// Every UI string lives in `assets/data/i18n/<lang>.json`.
/// Missing keys fall back to English, then to the key itself, so the app never
/// crashes on an incomplete translation.
class AppLocalizations {
  final String languageCode;
  final Map<String, String> _values;
  final Map<String, String> _fallback;

  AppLocalizations(this.languageCode, this._values, this._fallback);

  String t(String key) => _values[key] ?? _fallback[key] ?? key;

  String tN(String key, Map<String, Object> args) {
    var out = t(key);
    args.forEach((k, v) => out = out.replaceAll('{$k}', '$v'));
    return out;
  }

  bool get isRtl => const ['ar', 'ur', 'fa', 'he'].contains(languageCode);
}

class L10n {
  L10n._();

  static const List<String> codes = AppConfig.uiLanguages;

  static Map<String, String> _current = <String, String>{};
  static Map<String, String> _english = <String, String>{};
  static String _loadedCode = '';

  static Locale localeOf(String code) => Locale(code);

  /// Right-to-left languages (Arabic, Urdu, Persian, Hebrew...).
  static bool isRtl(String code) =>
      const ['ar', 'ur', 'fa', 'he'].contains(code);

  static List<Locale> get supportedLocales =>
      codes.map((c) => Locale(c)).toList(growable: false);

  static const List<LocalizationsDelegate<dynamic>> delegates = [
    _L10nDelegate(),
    DefaultMaterialLocalizations.delegate,
    DefaultWidgetsLocalizations.delegate,
  ];

  /// Native display name of every shipped language (no translation needed).
  static const Map<String, String> nativeNames = {
    'ar': 'العربية',
    'en': 'English',
    'fr': 'Français',
    'es': 'Español',
    'de': 'Deutsch',
    'it': 'Italiano',
    'tr': 'Türkçe',
    'ru': 'Русский',
    'zh': '中文',
    'hi': 'हिन्दी',
    'pt': 'Português',
    'ur': 'اردو',
  };

  static Future<void> load(String code) async {
    if (_english.isEmpty) {
      _english = await _read('en');
    }
    if (code == 'en') {
      _current = _english;
    } else {
      _current = await _read(code);
    }
    _loadedCode = code;
  }

  static Future<Map<String, String>> _read(String code) async {
    try {
      final raw = await rootBundle.loadString('assets/data/i18n/$code.json');
      final decoded = json.decode(raw) as Map<String, dynamic>;
      return decoded.map((k, v) => MapEntry(k, '$v'));
    } catch (e) {
      debugPrint('i18n: cannot load "$code" ($e)');
      return <String, String>{};
    }
  }

  static AppLocalizations bundle(String code) {
    if (code != _loadedCode) {
      // Language switch: the JSON is already cached by AppState before notify.
      load(code);
    }
    return AppLocalizations(code, _current, _english);
  }
}

class _L10nDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _L10nDelegate();

  @override
  bool isSupported(Locale locale) => L10n.codes.contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) {
    final code = L10n.codes.contains(locale.languageCode)
        ? locale.languageCode
        : 'en';
    return SynchronousFuture<AppLocalizations>(L10n.bundle(code));
  }

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppLocalizations> old) =>
      true;
}

extension L10nContext on BuildContext {
  AppLocalizations get l10n =>
      Localizations.of<AppLocalizations>(this, AppLocalizations) ??
      AppLocalizations('en', const {}, const {});
}

/// Reads a `{"ar": "...", "en": "..."}` map for the active language.
String localized(Map<String, dynamic>? map, String lang) {
  if (map == null || map.isEmpty) return '';
  final value = map[lang] ??
      map['en'] ??
      map[AppConfig.articleLanguages.first] ??
      map.values.first;
  return '$value';
}
