package com.irontitan.coach

import android.content.Intent
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Iron Titan - Android entry point.
 *
 * Adds one small native capability the Dart side needs:
 * "openKeyboardSettings" -> opens the system keyboard picker so the user can
 * change the keyboard (Gboard, Samsung, SwiftKey...) from inside the app.
 *
 * Copy this file to:
 * android/app/src/main/kotlin/com/irontitan/coach/MainActivity.kt
 * (keep the package line identical to your applicationId)
 */
class MainActivity : FlutterActivity() {

    private val channelName = "com.irontitan.coach/system"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "openKeyboardSettings" -> {
                        try {
                            val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(intent)
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }
}
