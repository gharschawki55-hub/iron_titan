# IRON TITAN — Weightlifting Coach

Real, installable cross-platform app (Flutter): **Android APK/AAB · iOS IPA · Windows EXE**.
One codebase, 100 % offline content, ads only when online.

---

## 1. Ce qui est déjà fait

| Demande | Où c'est dans le projet |
|---|---|
| 100 % hors ligne | Tous les textes/images sont dans `assets/`. Aucun appel réseau sauf la pub. |
| Accueil noir & or, photo héros | `lib/screens/home_screen.dart` + `assets/images/hero.jpg` |
| Prise de masse (guide, séries/reps/repos, aliments, protéines/carbs/eau, heure d'entraînement) | `bulk_screen.dart`, `assets/data/content/guides.json`, `exercises.json` |
| Sèche (cardio, alimentation, planning hebdo) | `cut_screen.dart` |
| Nutrition (repas matin/midi/soir, avant/après, boissons, vitamines) | `nutrition_screen.dart`, `nutrition.json` |
| Programmes + minuteur de repos | `programs_screen.dart`, `timer_screen.dart` |
| "Analyser mon corps" depuis la galerie | `analysis_screen.dart` + `services/body_analysis_service.dart` |
| Réglages : langues, partage, clavier, couleur de barre, jour/nuit | `settings_screen.dart` |
| AdMob : interstitiel 15 s au lancement, rewarded 30 s, bannière, coupure hors ligne | `services/ads_service.dart`, `core/app_config.dart` |
| Confidentialité, à propos, contact, avertissement médical | `legal_screen.dart`, `legal.json` |

### Langues
Interface **entièrement traduite** : `ar, en, fr, es, de, it, tr, ru, zh, hi, pt, ur`
(`assets/data/i18n/<code>.json`). Ajouter une langue = copier un fichier JSON.
L'arabe et l'ourdou inversent la mise en page (RTL) : la direction est pilotée par
`L10n.isRtl()` dans `app.dart`.
Les guides longs (articles) sont rédigés en **arabe, anglais, français** ; les autres
langues retombent sur l'anglais pour ces articles (l'interface reste traduite).

### Ce qu'il faut savoir (honnêteté)
* **Analyse photo** : l'app ouvre la galerie, garde la photo sur l'appareil et calcule
  un programme complet à partir de tes mensurations + de formules scientifiques
  (IMU, Navy body-fat, Mifflin-St Jeor). Ce n'est pas un réseau de neurones : une vraie
  détection visuelle des muscles demande un modèle IA (cloud ou modèle embarqué de
  plusieurs dizaines de Mo). Un point d'extension est prêt :
  `AppConfig.visionEndpoint` / `visionApiKey` (vide = 100 % offline).
* **Photos de Ronnie Coleman** : impossible de livrer des photos d'une personne réelle
  sans licence (droit à l'image + droits voisins) — ce serait un motif de rejet Play
  Store. Le projet contient donc **8 visuels originaux** (athlète noir & or, générés
  pour ce projet). Si tu possèdes des photos sous licence, remplace simplement
  `assets/images/hero.jpg` (et les autres) par les tiennes, sans toucher au code.
* **eCPM** : personne ne peut garantir "l'annonce qui paie le plus au monde". Le format
  qui paie le mieux en moyenne dans le fitness est le **rewarded video** (déjà intégré),
  puis l'interstitiel. Le prix réel dépend de ton compte AdMob, du pays et des
  annonceurs. Utilise la médiation AdMob si tu veux empiler plusieurs réseaux.

---

## 2. Prérequis (une seule fois)

1. **Flutter SDK** ≥ 3.24 : https://docs.flutter.dev/get-started/install
   ```powershell
   flutter --version
   flutter doctor
   ```
2. **Android Studio** (SDK Android + JDK 17) pour l'APK.
3. **macOS + Xcode** pour l'iOS (obligatoire, aucune exception Apple).
4. **Visual Studio 2022 + "Desktop development with C++"** pour Windows.
5. Un compte **Google AdMob** : https://apps.admob.com

---

## 3. Créer le projet et y injecter le code

```powershell
# 1) créer la coquille native (Android + iOS + Windows)
mkdir C:\dev\iron_titan
cd C:\dev\iron_titan
flutter create --org com.irontitan --project-name iron_titan --platforms=android,ios,windows .

# 2) copier par-dessus le contenu de ce dossier "app"
#    (lib/, assets/, pubspec.yaml, platform/)
# 3) installer les dépendances
flutter pub get

# 4) générer les icônes
dart run flutter_launcher_icons
```

Puis appliquer les 4 fichiers natifs :

| De | Vers |
|---|---|
| `platform/android/AndroidManifest.xml` | `android/app/src/main/AndroidManifest.xml` |
| `platform/android/MainActivity.kt` | `android/app/src/main/kotlin/com/irontitan/coach/MainActivity.kt` |
| `platform/ios/Info.plist` | `ios/Runner/Info.plist` |
| `platform/android/build.gradle.kts.reference` | à reporter dans `android/app/build.gradle.kts` |

> **Important — identifiant de package.** Le `build.gradle.kts.reference` impose
> `namespace` / `applicationId = "com.irontitan.coach"`, et `MainActivity.kt`
> déclare `package com.irontitan.coach`. `flutter create --org com.irontitan
> --project-name iron_titan` génère donc un `MainActivity.kt` inutile dans
> `android/app/src/main/kotlin/com/irontitan/iron_titan/` : **supprime ce
> fichier** (sinon deux classes `MainActivity` cohabitent dans le projet).
> Si tu préfères garder `com.irontitan.iron_titan`, remplace les 4 occurrences
> de `com.irontitan.coach` (`MainActivity.kt` ×2, `build.gradle.kts` ×2) par
> `com.irontitan.iron_titan` et garde celui de `flutter create`.

---

## 4. Où coller ses identifiants AdMob (3 endroits)

1. **`lib/core/app_config.dart`** → les 3 *Ad Unit ID* (interstitiel, rewarded, bannière)
   ```dart
   static const String _androidInterstitial = 'ca-app-pub-TON_ID/xxxx';
   static const String _androidRewarded     = 'ca-app-pub-TON_ID/xxxx';
   static const String _androidBanner       = 'ca-app-pub-TON_ID/xxxx';
   ```
2. **`android/app/src/main/AndroidManifest.xml`** → balise
   `com.google.android.gms.ads.APPLICATION_ID` (App ID Android).
3. **`ios/Runner/Info.plist`** → clé `GADApplicationIdentifier` (App ID iOS).

Les valeurs livrées sont les **ID de test officiels Google** : elles n'engrangent
aucun revenu et ne violent aucune règle. Remplace-les avant publication.

---

## 5. Compiler l'APK (téléphone)

```powershell
cd C:\dev\iron_titan
flutter build apk --release
```
Résultat : `build\app\outputs\flutter-apk\app-release.apk`
→ copie-le sur le téléphone et installe-le (activer "Sources inconnues").

Par architecture (APK plus légers) :
```powershell
flutter build apk --release --split-per-abi
```

## 6. Compiler le bundle Play Store (.aab)

```powershell
flutter build appbundle --release
```
Résultat : `build\app\outputs\bundle\release\app-release.aab`
Signature : voir la section "Release signing" dans
`platform/android/build.gradle.kts.reference` (créer le keystore **une seule fois**,
le garder pour toutes les mises à jour).

## 7. Compiler l'iOS (obligatoirement sur Mac)

```bash
flutter build ios --release
open ios/Runner.xcworkspace       # Xcode -> Product > Archive -> Distribute App
```
Il faut : un compte Apple Developer (99 $/an), un Bundle Identifier unique,
et « Signing & Capabilities > Automatically manage signing ».

## 8. Compiler Windows (EXE)

```powershell
flutter config --enable-windows-desktop
flutter build windows --release
```
Résultat : `build\windows\x64\runner\Release\iron_titan.exe`
(voir `platform/windows/README.md` pour l'installateur).

---

## 9. Checklist Play Store (pour éviter un refus)

- [ ] `applicationId` unique + keystore de release conservé.
- [ ] `targetSdk = 34`, `minSdk = 23`.
- [ ] Remplacer les ID AdMob de test par les vrais.
- [ ] **Data safety** : déclarer "Advertising ID" collecté par AdMob, aucune donnée
      personnelle pour le reste (l'app ne demande ni compte ni email).
- [ ] **Politique de confidentialité** : héberger le texte de l'écran Confidentialité
      sur une URL publique et la saisir dans la fiche Play.
- [ ] **Content rating** : questionnaire IARC (l'app contient des pubs).
- [ ] **Ads declaration** : "This app contains ads" = Oui.
- [ ] Écran de consentement pub intégré (déjà fait) → conforme RGPD/DMA.
- [ ] Aucune image sous copyright (voir note Ronnie Coleman).
- [ ] Captures d'écran + icône 512×512 + bannière 1024×500.
- [ ] Tester `flutter build apk --release` sur un vrai appareil avant l'envoi.

---

## 10. Modifier le contenu (sans coder)

Tout est du JSON, éditable dans un bloc-notes :

| Fichier | Contenu |
|---|---|
| `assets/data/content/exercises.json` | groupes musculaires, séries, reps, repos, tempo, conseils |
| `assets/data/content/programs.json` | programme masse 5 jours, sèche 6 jours, échauffement, règles de repos |
| `assets/data/content/nutrition.json` | repas, avant/après entraînement, compléments, listes manger/éviter, eau |
| `assets/data/content/guides.json` | guides longs (masse, sèche, heure d'entraînement, erreurs, progrès) |
| `assets/data/content/legal.json` | confidentialité, à propos, contact, avertissement médical |
| `assets/data/i18n/<code>.json` | toutes les chaînes de l'interface |

Après modification : `flutter build apk --release` (ou `flutter run` pour tester).

---

## 10 bis. Vérifier le projet sans Flutter (contrôle qualité)

Un audit statique est livré : `python tools/audit.py` (Python 3, aucune dépendance).
Il vérifie, sans SDK Flutter :

* chaque clé `t('…')` utilisée dans `lib/` existe dans `en.json` **et** dans les 12 langues ;
* chaque chemin d'asset (`assets/images/...`, JSON) existe vraiment ;
* la structure des 5 fichiers de contenu JSON attendue par `ContentRepository` ;
* chaque `ref` de programme existe dans `exercises.json` (+ images associées) ;
* chaque `import` relatif pointe vers un fichier existant ;
* parenthèses / accolades / crochets équilibrés (hors commentaires et chaînes) ;
* piège Dart `num.clamp()` : le résultat doit passer par `.toInt()` / `.toDouble()`
  avant d'être affecté à un `int` (erreur de compilation, déjà corrigée dans
  `timer_screen.dart`).

Sortie attendue : `AUDIT OK`. À relancer après toute modification de contenu.

---

## 11. Architecture

```
lib/
  main.dart                  démarrage, chargement des traductions + contenus
  app.dart                   MaterialApp, thème dynamique, locale
  core/
    app_config.dart          TOUS les réglages (AdMob, email, version)
    app_state.dart           langue, couleur, jour/nuit, consentement (persistés)
    l10n.dart                chargeur de traductions + extension context.t()
    theme.dart               10 accents, thème noir & or, clair/sombre
  data/content_repository.dart  lecture/typage du JSON embarqué
  services/
    ads_service.dart         AdMob (interstitiel, rewarded, bannière, garde-fous)
    body_analysis_service.dart  moteur de coaching offline (formules réelles)
    network_probe.dart       détection Internet sans plugin
    share_service.dart       partage + mailto + liens
  screens/                   10 écrans
  widgets/                   cartes, tuiles, vues de contenu
assets/data/                 contenu JSON (ar/en/fr pour les articles)
```

---

## 12. Trouver les ID de clés / Keys

**Android**
```powershell
keytool -genkey -v -keystore $env:USERPROFILE\iron-titan.jks -keyalg RSA -keysize 2048 -validity 10000 -alias irontitan
```
**iOS** : Xcode > Signing & Capabilities > Team.

---

# النسخة العربية — طريقة التجميع

1. ثبّت **Flutter** (3.24 أو أحدث) و **Android Studio**.
2. أنشئ المشروع:
   ```powershell
   flutter create --org com.irontitan --project-name iron_titan --platforms=android,ios,windows .
   ```
3. انسخ فوقه محتوى مجلد `app` (مجلدات `lib`, `assets`, `platform` وملف `pubspec.yaml`).
4. `flutter pub get` ثم `dart run flutter_launcher_icons`.
5. انسخ ملفات المنصات الأربعة المذكورة في الجدول أعلاه.
6. ضع معرّفات AdMob في **ثلاثة أماكن**: `lib/core/app_config.dart` و
   `AndroidManifest.xml` و `Info.plist`.
7. ابنِ التطبيق:
   ```powershell
   flutter build apk --release          # APK للأندرويد
   flutter build appbundle --release    # ملف Play Store
   flutter build windows --release      # برنامج الكمبيوتر
   flutter build ios --release          # على Mac فقط للآيفون
   ```
8. ملف APK تجده في: `build\app\outputs\flutter-apk\app-release.apk`

**ملاحظات مهمة:**
- التطبيق يعمل 100% بدون إنترنت. الإعلان يظهر فقط عند وجود إنترنت (يُفحص قبل الطلب).
- الصور الحالية أصلية (رياضي مستوحى، أسود وذهبي). صور روني كولمان الحقيقية تحتاج
  ترخيصاً، واستخدامها بدون ترخيص سبب رفض مؤكد في Play Store. استبدل
  `assets/images/hero.jpg` بصورتك المرخّصة إن توفّرت.
- زر "حلّل جسمي" يفتح المعرض ويحلّل الصورة + القياسات داخل الجهاز ويعطيك برنامجاً
  كاملاً. لتشغيل تحليل بصري بالذكاء الاصطناعي، املأ `visionEndpoint` في
  `app_config.dart` بعنوان خدمة خاصة بك.
