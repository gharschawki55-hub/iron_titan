﻿import 'package:flutter/material.dart';

/// A selectable app-wide accent ("toolbar color").
class AppAccent {
  final String id;
  final String labelKey;
  final Color color;
  const AppAccent(this.id, this.labelKey, this.color);
}

const List<AppAccent> kAccents = [
  AppAccent('gold', 'color_gold', Color(0xFFD4AF37)),
  AppAccent('sand', 'color_sand', Color(0xFFE7C87A)),
  AppAccent('crimson', 'color_red', Color(0xFFE0362B)),
  AppAccent('royal', 'color_blue', Color(0xFF2F6BFF)),
  AppAccent('emerald', 'color_green', Color(0xFF17B26A)),
  AppAccent('amethyst', 'color_purple', Color(0xFF9B5CFF)),
  AppAccent('rose', 'color_pink', Color(0xFFFF4D8D)),
  AppAccent('amber', 'color_orange', Color(0xFFFF9F1C)),
  AppAccent('teal', 'color_teal', Color(0xFF12C2C2)),
  AppAccent('silver', 'color_white', Color(0xFFE9E9EF)),
];

AppAccent accentById(String id) =>
    kAccents.firstWhere((a) => a.id == id, orElse: () => kAccents.first);

/// Text/icon color that stays readable on top of [background].
Color onColor(Color background) =>
    background.computeLuminance() > 0.55 ? const Color(0xFF101014) : Colors.white;

const Color kDarkScaffold = Color(0xFF0A0A0C);
const Color kDarkSurface = Color(0xFF14141A);
const Color kLightScaffold = Color(0xFFF5F4F0);
const Color kLightSurface = Color(0xFFFFFFFF);

ThemeData buildTheme(AppAccent accent, Brightness brightness) {
  final isDark = brightness == Brightness.dark;
  final primary = accent.color;
  final fg = onColor(primary);

  final base = ColorScheme.fromSeed(
    seedColor: primary,
    brightness: brightness,
  );

  final scheme = base.copyWith(
    primary: primary,
    onPrimary: fg,
    secondary: primary,
    onSecondary: fg,
    surface: isDark ? kDarkSurface : kLightSurface,
    onSurface: isDark ? const Color(0xFFEDEDF2) : const Color(0xFF14141A),
    error: const Color(0xFFE0362B),
  );

  final scaffold = isDark ? kDarkScaffold : kLightScaffold;
  final cardColor = isDark ? kDarkSurface : kLightSurface;

  final textTheme = (isDark ? ThemeData.dark() : ThemeData.light())
      .textTheme
      .apply(
        bodyColor: scheme.onSurface,
        displayColor: scheme.onSurface,
      );

  return ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: scheme,
    scaffoldBackgroundColor: scaffold,
    canvasColor: scaffold,
    splashFactory: InkRipple.splashFactory,
    appBarTheme: AppBarTheme(
      elevation: 0,
      centerTitle: false,
      backgroundColor: Color.alphaBlend(
        primary.withOpacity( isDark ? 0.10 : 0.14),
        scaffold,
      ),
      foregroundColor: isDark ? Colors.white : const Color(0xFF14141A),
      titleTextStyle: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w800,
        letterSpacing: 0.6,
        color: isDark ? Colors.white : const Color(0xFF14141A),
      ),
      iconTheme: IconThemeData(color: isDark ? Colors.white : const Color(0xFF14141A)),
    ),
    dividerTheme: DividerThemeData(
      color: primary.withOpacity( 0.18),
      thickness: 1,
      space: 1,
    ),
    chipTheme: ChipThemeData(
      backgroundColor: primary.withOpacity( 0.12),
      side: BorderSide(color: primary.withOpacity( 0.35)),
      labelStyle: TextStyle(
        color: isDark ? Colors.white : const Color(0xFF14141A),
        fontWeight: FontWeight.w600,
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: primary,
        foregroundColor: fg,
        minimumSize: const Size.fromHeight(58),
        textStyle: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: 0.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: primary,
        minimumSize: const Size.fromHeight(56),
        side: BorderSide(color: primary.withOpacity( 0.6), width: 1.4),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(foregroundColor: primary),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: primary.withOpacity( isDark ? 0.08 : 0.05),
      labelStyle: TextStyle(color: primary),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: primary.withOpacity( 0.35)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(color: primary, width: 1.6),
      ),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
    ),
    listTileTheme: ListTileThemeData(
      iconColor: primary,
      textColor: scheme.onSurface,
    ),
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      backgroundColor: Color.alphaBlend(
        primary.withOpacity( isDark ? 0.08 : 0.10),
        scaffold,
      ),
      selectedItemColor: primary,
      unselectedItemColor: isDark ? Colors.white54 : Colors.black45,
      type: BottomNavigationBarType.fixed,
      showUnselectedLabels: false,
      elevation: 0,
    ),
    textTheme: textTheme.copyWith(
      headlineLarge: textTheme.headlineLarge?.copyWith(
        fontWeight: FontWeight.w900,
        letterSpacing: 1.2,
      ),
      headlineSmall: textTheme.headlineSmall?.copyWith(
        fontWeight: FontWeight.w800,
        letterSpacing: 0.6,
      ),
      titleMedium: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: isDark ? const Color(0xFF23232C) : const Color(0xFF23232C),
      contentTextStyle: const TextStyle(color: Colors.white),
      behavior: SnackBarBehavior.floating,
    ),
    extensions: <ThemeExtension<dynamic>>[AppColors(accent: primary, isDark: isDark)],
  );
}

/// Small helper so widgets can read the accent without rebuilding a ThemeData.
@immutable
class AppColors extends ThemeExtension<AppColors> {
  final Color accent;
  final bool isDark;
  const AppColors({required this.accent, required this.isDark});

  @override
  AppColors copyWith({Color? accent, bool? isDark}) =>
      AppColors(accent: accent ?? this.accent, isDark: isDark ?? this.isDark);

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) return this;
    return AppColors(
      accent: Color.lerp(accent, other.accent, t) ?? accent,
      isDark: t < 0.5 ? isDark : other.isDark,
    );
  }
}

extension ThemeX on BuildContext {
  AppColors get colors =>
      Theme.of(this).extension<AppColors>() ??
      const AppColors(accent: Color(0xFFD4AF37), isDark: true);
  Color get accent => colors.accent;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
}
