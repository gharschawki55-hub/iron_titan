import 'package:flutter/material.dart';

import '../core/app_config.dart';
import '../core/theme.dart';
import '../data/content_repository.dart';
import '../services/share_service.dart';
import '../widgets/common.dart';

/// Generic page that renders a JSON legal document in the active language.
class LegalPage extends StatelessWidget {
  final String titleKey;
  final LegalDoc? doc;
  final List<Widget> extra;

  const LegalPage({
    super.key,
    required this.titleKey,
    required this.doc,
    this.extra = const [],
  });

  @override
  Widget build(BuildContext context) {
    final document = doc;
    if (document == null) {
      return AppPage(
        title: context.t(titleKey),
        child: Center(child: Text(context.t('common_loading'))),
      );
    }

    return AppPage(
      title: context.tr(document.title).isNotEmpty
          ? context.tr(document.title)
          : context.t(titleKey),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          if (context.tr(document.updated).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Text(
                context.tr(document.updated),
                style: TextStyle(
                  fontSize: 11.5,
                  color: context.accent,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          if (context.tr(document.body).isNotEmpty)
            GoldCard(
              child: Text(
                context.tr(document.body),
                style: const TextStyle(fontSize: 13.5, height: 1.6),
              ),
            ),
          for (final section in document.sections) ...[
            const SizedBox(height: 12),
            GoldCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    context.tr(section.title),
                    style: const TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    context.tr(section.body),
                    style: const TextStyle(fontSize: 13, height: 1.55),
                  ),
                ],
              ),
            ),
          ],
          ...extra,
        ],
      ),
    );
  }
}

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) => LegalPage(
        titleKey: 'settings_privacy',
        doc: ContentRepository.instance.privacy,
      );
}

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) => LegalPage(
        titleKey: 'settings_about',
        doc: ContentRepository.instance.about,
        extra: [
          const SizedBox(height: 16),
          GoldCard(
            child: Column(
              children: [
                Row(
                  children: [
                    Icon(Icons.fitness_center, color: context.accent),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        AppConfig.appName,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  '${context.t('settings_version')} ${AppConfig.version}+${AppConfig.buildNumber}',
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 48,
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: () =>
                        ShareService.shareApp(context.t('share_message')),
                    icon: const Icon(Icons.share_outlined, size: 18),
                    label: Text(context.t('share_title')),
                  ),
                ),
              ],
            ),
          ),
        ],
      );
}

class ContactScreen extends StatelessWidget {
  const ContactScreen({super.key});

  @override
  Widget build(BuildContext context) => LegalPage(
        titleKey: 'settings_contact',
        doc: ContentRepository.instance.contact,
        extra: [
          const SizedBox(height: 16),
          SizedBox(
            height: 54,
            child: ElevatedButton.icon(
              onPressed: () => ShareService.sendEmail(
                subject: '${AppConfig.appName} - contact',
                body: '',
              ),
              icon: const Icon(Icons.mail_outline, size: 20),
              label: Text(AppConfig.supportEmail),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 50,
            child: OutlinedButton.icon(
              onPressed: () => ShareService.openUrl(AppConfig.websiteUrl),
              icon: const Icon(Icons.public, size: 18),
              label: Text(AppConfig.websiteUrl),
            ),
          ),
        ],
      );
}

class DisclaimerScreen extends StatelessWidget {
  const DisclaimerScreen({super.key});

  @override
  Widget build(BuildContext context) => LegalPage(
        titleKey: 'settings_disclaimer',
        doc: ContentRepository.instance.disclaimer,
      );
}
