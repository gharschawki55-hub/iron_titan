import 'dart:math' as math;

/// ---------------------------------------------------------------------------
/// Offline coaching engine.
///
/// The photo is captured from the gallery and stored locally by the app. The
/// numbers below come from published, standard formulas:
///   * BMI                        -> Quetelet
///   * Body fat                   -> US Navy circumference method (fallback:
///                                   Deurenberg BMI equation)
///   * Basal metabolic rate       -> Mifflin-St Jeor
///   * Daily needs                -> BMR x activity factor
///   * Protein / fat / water      -> evidence-based ranges for lifters
/// Everything runs on the device: no image is ever uploaded.
/// If the owner later configures a cloud vision endpoint in AppConfig, the
/// screen can merge its answer on top of this offline result.
/// ---------------------------------------------------------------------------

class BodyProfile {
  final bool male;
  final int age;
  final double heightCm;
  final double weightKg;
  final double waistCm;
  final double neckCm;
  final double chestCm;
  final double armCm;
  final double hipCm;
  final int trainingMonths;
  final String goal; // 'auto' | 'bulk' | 'cut'
  final String priority; // '' or muscle group id
  final String? photoPath;

  BodyProfile({
    required this.male,
    required this.age,
    required this.heightCm,
    required this.weightKg,
    required this.waistCm,
    required this.neckCm,
    required this.chestCm,
    required this.armCm,
    required this.hipCm,
    required this.trainingMonths,
    required this.goal,
    required this.priority,
    this.photoPath,
  });
}

class BodyAnalysisResult {
  final double bmi;
  final double bodyFatPct;
  final double bmr;
  final double tdee;
  final double calories;
  final double proteinG;
  final double carbsG;
  final double fatG;
  final double waterL;
  final String direction; // bulk | cut | maintain
  final String programId; // bulking | cutting
  final List<String> weakGroups;
  final List<String> strongGroups;
  final List<String> focusRefs;

  BodyAnalysisResult({
    required this.bmi,
    required this.bodyFatPct,
    required this.bmr,
    required this.tdee,
    required this.calories,
    required this.proteinG,
    required this.carbsG,
    required this.fatG,
    required this.waterL,
    required this.direction,
    required this.programId,
    required this.weakGroups,
    required this.strongGroups,
    required this.focusRefs,
  });
}

class BodyAnalysisService {
  BodyAnalysisService._();

  static const Map<String, List<String>> _groupExercises = {
    'chest': ['Incline Dumbbell Press', 'Cable Crossover'],
    'back': ['Barbell Row', 'Weighted Pull-up'],
    'shoulders': ['Dumbbell Lateral Raise', 'Rear Delt Fly'],
    'arms': ['Incline Dumbbell Curl', 'Overhead Triceps Extension'],
    'legs': ['Barbell Back Squat', 'Romanian Deadlift'],
    'abs': ['Hanging Leg Raise', 'Ab Wheel Rollout'],
  };

  static BodyAnalysisResult analyse(BodyProfile p) {
    final heightM = math.max(p.heightCm, 100) / 100.0;
    final bmi = p.weightKg / (heightM * heightM);

    final bodyFat = _bodyFat(p, bmi);

    final bmr = 10 * p.weightKg +
        6.25 * p.heightCm -
        5 * p.age +
        (p.male ? 5 : -161);

    final activity = p.trainingMonths < 3
        ? 1.375
        : p.trainingMonths < 12
            ? 1.50
            : p.trainingMonths < 36
                ? 1.65
                : 1.75;
    final tdee = bmr * activity;

    final direction = _direction(p, bodyFat);
    final double calories;
    switch (direction) {
      case 'bulk':
        calories = tdee + 400;
        break;
      case 'cut':
        calories = tdee - 450;
        break;
      default:
        calories = tdee;
    }

    final protein = p.weightKg * (direction == 'cut' ? 2.3 : 2.0);
    final fat = p.weightKg * 0.9;
    final carbs = math.max(80.0, (calories - protein * 4 - fat * 9) / 4);
    final water = p.weightKg * 0.035 + 0.5;

    final scores = _scores(p);
    final weak = <String>[];
    final strong = <String>[];
    scores.forEach((group, score) {
      if (score < 0.95) weak.add(group);
      if (score > 1.05) strong.add(group);
    });
    weak.sort((a, b) => (scores[a] ?? 1).compareTo(scores[b] ?? 1));
    strong.sort((a, b) => (scores[b] ?? 1).compareTo(scores[a] ?? 1));

    if (p.priority.isNotEmpty && !weak.contains(p.priority)) {
      weak.insert(0, p.priority);
    }

    final focus = <String>[];
    for (final group in weak.take(2)) {
      focus.addAll(_groupExercises[group] ?? const []);
    }
    for (final base in _baselineRefs(p.trainingMonths)) {
      if (!focus.contains(base)) focus.add(base);
    }

    return BodyAnalysisResult(
      bmi: bmi,
      bodyFatPct: bodyFat,
      bmr: bmr,
      tdee: tdee,
      calories: calories,
      proteinG: protein,
      carbsG: carbs,
      fatG: fat,
      waterL: water,
      direction: direction,
      programId: direction == 'cut' ? 'cutting' : 'bulking',
      weakGroups: weak.take(3).toList(),
      strongGroups: strong.take(3).toList(),
      focusRefs: focus.take(6).toList(),
    );
  }

  static double _bodyFat(BodyProfile p, double bmi) {
    double bf;
    if (p.waistCm > 0 && p.neckCm > 0 && p.heightCm > 0) {
      if (p.male) {
        final diff = math.max(p.waistCm - p.neckCm, 1.0);
        final v = 1.0324 -
            0.19077 * (math.log(diff) / math.ln10) +
            0.15456 * (math.log(p.heightCm) / math.ln10);
        bf = 495 / v - 450;
      } else {
        final hip = p.hipCm > 0 ? p.hipCm : p.waistCm * 1.15;
        final sum = math.max(p.waistCm + hip - p.neckCm, 1.0);
        final v = 1.29579 -
            0.35004 * (math.log(sum) / math.ln10) +
            0.22100 * (math.log(p.heightCm) / math.ln10);
        bf = 495 / v - 450;
      }
    } else {
      bf = 1.20 * bmi + 0.23 * p.age - 10.8 * (p.male ? 1 : 0) - 5.4;
    }
    return bf.clamp(3.0, 60.0).toDouble();
  }

  static String _direction(BodyProfile p, double bodyFat) {
    if (p.goal == 'bulk') return 'bulk';
    if (p.goal == 'cut') return 'cut';
    if (p.male) {
      if (bodyFat >= 18) return 'cut';
      if (bodyFat <= 12) return 'bulk';
      return 'maintain';
    }
    if (bodyFat >= 27) return 'cut';
    if (bodyFat <= 21) return 'bulk';
    return 'maintain';
  }

  static Map<String, double> _scores(BodyProfile p) {
    final scores = <String, double>{};
    if (p.waistCm <= 0) return scores;

    if (p.chestCm > 0) {
      final ideal = p.male ? 0.78 : 0.72;
      scores['chest'] = (p.chestCm / p.waistCm) / ideal;
    }
    if (p.armCm > 0) {
      final ideal = p.male ? 0.42 : 0.38;
      scores['arms'] = (p.armCm / p.waistCm) / ideal;
    }
    if (p.waistCm / math.max(p.heightCm, 1) > 0.55) {
      scores['abs'] = 0.80;
    }
    return scores;
  }

  static List<String> _baselineRefs(int months) {
    if (months < 6) {
      return ['Barbell Back Squat', 'Barbell Bench Press', 'Barbell Row'];
    }
    if (months < 24) {
      return [
        'Barbell Back Squat',
        'Barbell Bench Press',
        'Deadlift',
        'Standing Overhead Press',
      ];
    }
    return [
      'Barbell Back Squat',
      'Barbell Bench Press',
      'Deadlift',
      'Weighted Pull-up',
    ];
  }
}
