import 'package:flutter/material.dart';

import '../core/app_config.dart';
import '../core/app_state.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/ads_service.dart';
import '../services/share_service.dart';
import '../widgets/common.dart';
import 'legal_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final accent = context.accent;

    return AppPage(
      title: context.t('settings_title'),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
        children: [
          // ------------------------------------------------------------ language
          SectionHeader(title: context.t('settings_language')),
          GoldCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                for (final code in L10n.codes)
                  ListTile(
                    dense: true,
                    leading: Icon(
                      code == state.language
                          ? Icons.radio_button_checked
                          : Icons.radio_button_off,
                      size: 20,
                      color: code == state.language
                          ? accent
                          : Theme.of(context)
                              .colorScheme
                              .onSurface
                              .withOpacity(0.4),
                    ),
                    title: Text(
                      L10n.nativeNames[code] ?? code,
                      style: TextStyle(
                        fontSize: 14.5,
                        fontWeight: code == state.language
                            ? FontWeight.w800
                            : FontWeight.w500,
                      ),
                    ),
                    subtitle: Text(
                      code.toUpperCase(),
                      style: const TextStyle(fontSize: 10.5, letterSpacing: 1),
                    ),
                    onTap: () => state.setLanguage(code),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(
              context.t('content_lang_note'),
              style: TextStyle(
                fontSize: 11.5,
                height: 1.4,
                color:
                    Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
              ),
            ),
          ),

          // ---------------------------------------------------------- appearance
          SectionHeader(title: context.t('settings_appearance')),
          GoldCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  context.t('settings_theme'),
                  style: const TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: [
                    _modeChip(context, state, ThemeMode.light,
                        context.t('settings_light')),
                    _modeChip(context, state, ThemeMode.dark,
                        context.t('settings_dark')),
                    _modeChip(context, state, ThemeMode.system,
                        context.t('settings_system')),
                  ],
                ),
                const SizedBox(height: 18),
                Text(
                  context.t('settings_color'),
                  style: const TextStyle(
                      fontSize: 13.5, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    for (final option in kAccents)
                      GestureDetector(
                        onTap: () => state.setAccent(option.id),
                        child: Column(
                          children: [
                            Container(
                              width: 44,
                              height: 44,
                              decoration: BoxDecoration(
                                color: option.color,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: state.accentId == option.id
                                      ? Theme.of(context).colorScheme.onSurface
                                      : Colors.transparent,
                                  width: 2.4,
                                ),
                              ),
                              child: state.accentId == option.id
                                  ? Icon(
                                      Icons.check,
                                      size: 20,
                                      color: onColor(option.color),
                                    )
                                  : null,
                            ),
                            const SizedBox(height: 4),
                            SizedBox(
                              width: 56,
                              child: Text(
                                context.t(option.labelKey),
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 9.5),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),

          // -------------------------------------------------------- keyboard/share
          SectionHeader(title: context.t('settings_keyboard')),
          GoldCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.keyboard_outlined),
                  title: Text(context.t('settings_keyboard')),
                  subtitle: Text(
                    context.t('settings_keyboard_sub'),
                    style: const TextStyle(fontSize: 11.5),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _openKeyboard(context),
                ),
                Divider(color: accent.withOpacity(0.15), height: 1),
                ListTile(
                  leading: const Icon(Icons.share_outlined),
                  title: Text(context.t('settings_share')),
                  subtitle: Text(
                    context.t('settings_share_sub'),
                    style: const TextStyle(fontSize: 11.5),
                  ),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => ShareService.shareApp(context.t('share_message')),
                ),
              ],
            ),
          ),

          // ------------------------------------------------------------------ ads
          if (AppConfig.adsEnabled && AdsService.platformSupported) ...[
            SectionHeader(title: context.t('settings_ads')),
            GoldCard(
              padding: EdgeInsets.zero,
              child: SwitchListTile(
                value: state.adConsent,
                onChanged: (value) async {
                  await state.setAdConsent(value);
                  AdsService.instance.consent = value;
                },
                title: Text(context.t('settings_consent')),
                subtitle: Text(
                  context.t('settings_consent_body'),
                  style: const TextStyle(fontSize: 11.5, height: 1.35),
                ),
                activeColor: accent,
              ),
            ),
          ],

          // ----------------------------------------------------------------- legal
          SectionHeader(title: context.t('settings_about')),
          GoldCard(
            padding: EdgeInsets.zero,
            child: Column(
              children: [
                _link(context, Icons.shield_outlined, context.t('settings_privacy'),
                    const PrivacyScreen()),
                _link(context, Icons.info_outline, context.t('settings_about'),
                    const AboutScreen()),
                _link(context, Icons.mail_outline, context.t('settings_contact'),
                    const ContactScreen()),
                _link(context, Icons.health_and_safety,
                    context.t('settings_disclaimer'), const DisclaimerScreen()),
              ],
            ),
          ),
          const SizedBox(height: 18),
          Center(
            child: Text(
              '${AppConfig.appName} · ${context.t('settings_version')} ${AppConfig.version}+${AppConfig.buildNumber}',
              style: TextStyle(
                fontSize: 11,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.45),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _modeChip(
    BuildContext context,
    AppState state,
    ThemeMode mode,
    String label,
  ) {
    final selected = state.themeMode == mode;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      showCheckmark: false,
      selectedColor: context.accent.withOpacity(0.25),
      onSelected: (_) => state.setThemeMode(mode),
    );
  }

  Widget _link(BuildContext context, IconData icon, String label, Widget page) {
    return ListTile(
      dense: true,
      leading: Icon(icon, size: 20),
      title: Text(label, style: const TextStyle(fontSize: 14)),
      trailing: const Icon(Icons.chevron_right, size: 18),
      onTap: () => pushPage(context, page),
    );
  }

  Future<void> _openKeyboard(BuildContext context) async {
    final opened = await KeyboardService.openKeyboardSettings();
    if (!context.mounted) return;
    if (!opened) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(context.t('settings_keyboard_sub'))),
      );
    }
  }
}
