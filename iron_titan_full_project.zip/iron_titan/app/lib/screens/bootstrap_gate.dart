import 'package:flutter/material.dart';

import '../core/app_config.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../services/ads_service.dart';
import '../widgets/common.dart';
import 'main_shell.dart';

/// Shows the branded splash, asks for the advertising consent once, plays the
/// launch interstitial when the network allows it, then opens the app.
class BootstrapGate extends StatefulWidget {
  const BootstrapGate({super.key});

  @override
  State<BootstrapGate> createState() => _BootstrapGateState();
}

class _BootstrapGateState extends State<BootstrapGate> {
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _boot());
  }

  Future<void> _boot() async {
    await Future<void>.delayed(const Duration(milliseconds: 850));
    if (!mounted) return;

    final state = AppStateScope.of(context);

    if (AppConfig.adsEnabled && AdsService.platformSupported) {
      if (!state.onboarded) {
        final accepted = await _askConsent(state);
        await state.setAdConsent(accepted);
        await state.markOnboarded();
      }
      AdsService.instance.consent = state.adConsent;
      await AdsService.instance.init();
      if (AppConfig.interstitialOnLaunch && state.adConsent) {
        await AdsService.instance.maybeShowInterstitial(force: true);
      }
    }

    if (!mounted) return;
    setState(() => _ready = true);
  }

  Future<bool> _askConsent(AppState state) async {
    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(ctx.t('settings_consent_title')),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(ctx.t('settings_consent_body'), style: const TextStyle(height: 1.45)),
              const SizedBox(height: 14),
              Text(
                ctx.t('home_offline_note'),
                style: TextStyle(
                  fontSize: 12.5,
                  color: Theme.of(ctx).colorScheme.onSurface.withOpacity(0.7),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: Text(ctx.t('settings_decline')),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: Text(ctx.t('settings_agree')),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return const MainShell();

    final accent = context.accent;
    return Scaffold(
      backgroundColor: const Color(0xFF07070A),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/images/hero.jpg',
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF07070A)),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xCC000000), Color(0x66000000), Color(0xFF07070A)],
                stops: [0.0, 0.45, 1.0],
              ),
            ),
          ),
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 10),
                  decoration: BoxDecoration(
                    border: Border.all(color: accent, width: 1.6),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    'IRON TITAN',
                    style: TextStyle(
                      color: accent,
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 5,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  context.t('app_tagline').toUpperCase(),
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    letterSpacing: 3.4,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 44),
                SizedBox(
                  width: 26,
                  height: 26,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.2,
                    valueColor: AlwaysStoppedAnimation<Color>(accent),
                  ),
                ),
                const SizedBox(height: 28),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
